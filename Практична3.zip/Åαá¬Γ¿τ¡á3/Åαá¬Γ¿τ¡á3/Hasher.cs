﻿using System;

namespace Практична3
{
    internal class Hasher
    {
        static public string HashPassword(string password)
        {
            long hash = 0;
            const int N = 26;
            int current = 0;

            for (int i = password.Length - 1; i >= 0; i--)
            {
                hash += ((int)password[current] - 47) * (long)Math.Pow(N, i);
                current++;
            }

            return hash.ToString();
        }
    }
}
