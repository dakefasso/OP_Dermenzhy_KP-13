﻿using System.Windows;
using Npgsql;

namespace Практична3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            userButton.Click += (s, e) => ShowUserLoginWindow();
            adminButton.Click += (s, e) => ShowAdminLoginWindow();
            developerButton.Click += (s, e) => ShowDevWindow();
            closeButton.Click += (s, e) => Close();
        }

        private void ShowUserLoginWindow()
        {
            UserLoginWindow userLoginWindow = new UserLoginWindow();
            userLoginWindow.Show();
            Close();
        }

        private void ShowDevWindow()
        {
            DevWindow devWindow = new DevWindow();
            devWindow.Show();
            Close();
        }

        private void ShowAdminLoginWindow()
        {
            AdminLoginWindow adminLoginWindow = new AdminLoginWindow();
            adminLoginWindow.Show();
            Close();
        }
    }
}
