﻿using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace Практична3
{
    /// <summary>
    /// Interaction logic for AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        Label? samePassWarn;
        User[] users;
        int currentUser = 0;
        public AdminWindow()
        {
            InitializeComponent();

            setNewPassButton.IsEnabled = false;
            repeatPassTextBox.IsEnabled = false;

            newUserLoginField.TextChanged += (s, e) => NewLoginChangedEvent();
            newPassTextBox.PasswordChanged += (s, e) => NewPassChangedEvent();
            repeatPassTextBox.PasswordChanged += (s, e) => RepeatPassChangedEvent();

            setNewPassButton.Click += (s, e) => SetNewPassword();
            backButton.Click += (s, e) => BackToMenu();
            addNewUserButton.Click += (s, e) => AddNewUser();
            changeRestrictionsButton.Click += (s, e) => ChangeRestrictionsEvent();
            changeStatusButton.Click += (s, e) => ChangeStatusEvent();
            deleteUserButton.Click += (s, e) => DeleteUser();
            nextUserButton.Click += (s, e) => NextUser();
            previousUserButton.Click += (s, e) => PreviousUser();

            users = GetUsers();
            DisplayUser(currentUser);
            usersDataGrid.ItemsSource = users;
        }

        private void NewPassChangedEvent()
        {
            repeatPassTextBox.Password = "";
            if (Hasher.HashPassword(newPassTextBox.Password) == PostgreExecuter.CheckPassword("ADMIN"))
            {
                SamePasswordWarning();
                repeatPassTextBox.IsEnabled = false;
            }
            else if (newPassTextBox.Password.Length > 0)
            {
                repeatPassTextBox.IsEnabled = true;
                try
                {
                    samePassWarn.Visibility = Visibility.Hidden;
                }
                catch { samePassWarn = null; }

            }
            else
            {
                repeatPassTextBox.IsEnabled = false;
                try
                {
                    samePassWarn.Visibility = Visibility.Hidden;
                }
                catch { samePassWarn = null; }
            }
        }

        private void RepeatPassChangedEvent()
        {
            if (repeatPassTextBox.Password == newPassTextBox.Password)
            {
                setNewPassButton.IsEnabled = true;
            }
            else
            {
                setNewPassButton.IsEnabled = false;
            }
        }

        private void SetNewPassword()
        {
            User user = new User();
            user.Login = "ADMIN";
            user.Password = Hasher.HashPassword(newPassTextBox.Password);

            PostgreExecuter.UpdateUser(user, user.Login);

            newPassTextBox.Password = "";
            repeatPassTextBox.Password = "";
        }

        private void ChangeRestrictionsEvent()
        {
            bool restrictions = restrictionsField.Text == "On"? false: true;
            users[currentUser].Restrictions = restrictions;
            PostgreExecuter.UpdateUser(users[currentUser], users[currentUser].Login);

            users = GetUsers();
            DisplayUser(currentUser);
        }

        private void ChangeStatusEvent()
        {
            bool status = statusField.Text == "On" ? false : true;
            users[currentUser].Status = status;
            PostgreExecuter.UpdateUser(users[currentUser], users[currentUser].Login);

            users = GetUsers();
            DisplayUser(currentUser);
        }

        private void NewLoginChangedEvent()
        {
            if (newUserLoginField.Text.Length > 0 && CheckLogin())
            {
                addNewUserButton.IsEnabled = true;
            }
            else
            {
                addNewUserButton.IsEnabled = false;
            }
        }

        private void AddNewUser()
        {
            User user = new User();
            user.Login = newUserLoginField.Text;
            user.Password = Hasher.HashPassword("");
            user.Name = "";
            user.Surname = "";
            user.Status = true;
            user.Restrictions = true;

            PostgreExecuter.InsertUser(user);
        }

        private void DeleteUser()
        {
            PostgreExecuter.DeleteUser(users[currentUser]);
            users = GetUsers();
            DisplayUser(currentUser);
        }

        private void PreviousUser()
        {
            if (currentUser == 0)
            {
                currentUser = users.Length - 1;
            }
            else
            {
                currentUser--;
            }
            users = GetUsers();
            DisplayUser(currentUser);
        }

        private void NextUser()
        {
            if (users.Length == currentUser + 1)
            {
                currentUser = 0;
            }
            else
            {
                currentUser++;
            }
            users = GetUsers();
            DisplayUser(currentUser);
        }

        private void SamePasswordWarning()
        {
            samePassWarn = new Label();
            samePassWarn.Visibility = Visibility.Visible;
            samePassWarn.HorizontalAlignment = HorizontalAlignment.Left;
            samePassWarn.VerticalAlignment = VerticalAlignment.Top;
            samePassWarn.Margin = new Thickness(16, 77, 0, 0);
            samePassWarn.Content = "Новий пароль збігається зі старим";
            samePassWarn.FontFamily = new FontFamily("Century");
            samePassWarn.Foreground = Brushes.Red;
            samePassWarn.FontSize = 10;
            Grid.SetColumn(samePassWarn, 1);
            windowGrid.Children.Add(samePassWarn);
        }

        private bool CheckLogin()
        {
            string login = newUserLoginField.Text;

            NewLoginValidation loginValidation = new NewLoginValidation();
            CultureInfo culture = CultureInfo.InvariantCulture;

            if (loginValidation.Validate(newUserLoginField.Text, culture) == ValidationResult.ValidResult)
            {
                return true;
            }
            return false;
        }

        private void DisplayUser(int number)
        {
            nameField.Text = users[number].Name;
            surnameField.Text = users[number].Surname;
            loginField.Text = users[number].Login;
            restrictionsField.Text = users[number].Restrictions? "On": "Off";
            statusField.Text = users[number].Status ? "On" : "Off";

            deleteUserButton.IsEnabled = users.Length == 0 ? false : true;
        }

        private User[] GetUsers()
        {
            List<string> logins = PostgreExecuter.GetLogins();
            User[] users = new User[logins.Count];

            for (int i = 0; i < logins.Count; i++)
            {
                User user = PostgreExecuter.GetUser(logins[i]);
                users[i] = user;
            }

            return users;
        }

        private void BackToMenu()
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
