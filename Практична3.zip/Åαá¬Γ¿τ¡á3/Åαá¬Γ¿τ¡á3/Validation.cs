﻿using System;
using System.Globalization;
using System.Windows.Controls;

namespace Практична3
{
    public class NewLoginValidation : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            string password = PostgreExecuter.CheckLogin((value ?? "").ToString());

            if (password.Length != 0)
            {
                return new ValidationResult(false, "Логін зайнято");
            }
            else if (string.IsNullOrWhiteSpace((value ?? "").ToString()))
            {
                return new ValidationResult(false, "Логін не може бути пустим");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }

    public class LoginValidation : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            string password = PostgreExecuter.CheckLogin((value ?? "").ToString());
            bool available = PostgreExecuter.CkeckStatus((value ?? "").ToString());

            if (password.Length == 0 || (value ?? "").ToString() == "ADMIN")
            {
                return new ValidationResult(false, "Логін не знайдено");
                
            }
            else if (!available)
            {
                return new ValidationResult(false, "Акаунт деактивовано");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }

    public class NameValidation : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo) 
        { 
            if (string.IsNullOrWhiteSpace((value ?? "").ToString()))
            {
                return new ValidationResult(false, "Це поле не може бути пустим");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }

    public class PasswordValidation : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            bool containsDigits = false,
                 containsLetters = false,
                 restrictions = PostgreExecuter.CkeckRestrictions(CurrentLogin.Login);

            if (restrictions)
            {
                for (int i = 0; i < (value ?? "").ToString().Length; i++)
                {
                    char c = (value ?? "").ToString()[i];

                    if (char.IsDigit(c))
                    {
                        containsDigits = true;
                    }
                    else if (char.IsLetter(c))
                    {
                        containsLetters = true;
                    }
                }

                if ((value ?? "").ToString().Length < 8)
                {
                    return new ValidationResult(false, "Пароль має складатись з хоча б 8 символів");
                }
                else if (!containsDigits)
                {
                    return new ValidationResult(false, "Пароль має містити хоча б 1 цифру");
                }
                else if (!containsLetters)
                {
                    return new ValidationResult(false, "Пароль має містити хоча б 1 літеру");

                }
            }
            
            return ValidationResult.ValidResult;
        }
    }

    static public class CurrentLogin
    {
        static public string Login = "la-la";
    }
}
