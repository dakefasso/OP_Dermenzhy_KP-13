﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Практична3
{
    /// <summary>
    /// Interaction logic for AdminPassWindow.xaml
    /// </summary>
    public partial class AdminLoginWindow : Window
    {
        public AdminLoginWindow()
        {
            InitializeComponent();
            int errorCounter = 0;

            tryPassButton.IsEnabled = false;
            adminPassTextBox.PasswordChanged += (s, e) =>
            {
                if (adminPassTextBox.Password.Length > 0)
                {
                    tryPassButton.IsEnabled = true;
                }
                else
                {
                    tryPassButton.IsEnabled = false;
                }
            };

            tryPassButton.Click += (s, e) =>
            {
                if (PostgreExecuter.CheckLogin("ADMIN") == Hasher.HashPassword(adminPassTextBox.Password))
                {
                    AdminWindow adminWindow = new AdminWindow();
                    adminWindow.Show();
                    Close();
                }
                else
                {
                    adminPassTextBox.Password = "";
                    if (errorCounter == 0)
                    {
                        MessageBox.Show("Неправильний пароль. Залишилося 2 спроби");
                    }
                    else if (errorCounter == 1)
                    {
                        MessageBox.Show("Неправильний пароль. Залишилася 1 спроба");
                    }
                    else
                    {
                        Close();
                    }
                    errorCounter++;
                }
            };
        }
    }
}
