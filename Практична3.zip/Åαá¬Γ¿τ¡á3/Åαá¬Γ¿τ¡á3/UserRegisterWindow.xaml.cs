﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace Практична3
{
    public partial class UserRegisterWindow : Window
    {
        public UserRegisterWindow()
        {
            InitializeComponent();

            userPassBox.IsEnabled = false;
            //repeatPassBox.IsEnabled = false;
            registerButton.IsEnabled = false;

            userNameTextBox.TextChanged += (s, e) => CheckInput();
            userSurnameTextBox.TextChanged += (s, e) => CheckInput();
            userLoginTextBox.TextChanged += (s, e) => CheckInput();

            userPassBox.TextChanged += (s, e) =>
            {
                userNameTextBox.IsEnabled = false;
                userSurnameTextBox.IsEnabled = false;
                userLoginTextBox.IsEnabled = false;

                PasswordValidation passwordValidation = new PasswordValidation();
                CultureInfo culture = CultureInfo.InvariantCulture;

                if (passwordValidation.Validate(userPassBox.Text, culture) == ValidationResult.ValidResult) 
                {
                    registerButton.IsEnabled = true;
                    //repeatPassBox.IsEnabled = true;
                }
                else
                {
                    registerButton.IsEnabled = false;
                    //repeatPassBox.IsEnabled = false;
                }
            };

            //repeatPassBox.TextChanged += (s, e) =>
            //{
            //    if (repeatPassBox.Text.Length > 0) 
            //    {
            //        userPassBox.IsEnabled = false;
            //        if (repeatPassBox.Text == userPassBox.Text)
            //        {
            //            registerButton.IsEnabled = true;
            //            repeatPassBox.IsEnabled = false;
            //        }
            //    }
            //    else
            //    {
            //        userPassBox.IsEnabled = true;
            //    }
            //};

            registerButton.Click += (s, e) =>
            {
                User user = new User();

                user.Name = userNameTextBox.Text;
                user.Surname = userSurnameTextBox.Text;
                user.Login = userLoginTextBox.Text;
                user.Password = Hasher.HashPassword(userPassBox.Text);
                user.Restrictions = true;
                user.Status = true;

                PostgreExecuter.InsertUser(user);
                ToMenu();
            };

            backButton.Click += (s, e) => ToMenu();
        }

        private void ToMenu()
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

        private void CheckInput()
        {
            if (userNameTextBox.Text.Length > 0 && userSurnameTextBox.Text.Length > 0 && CheckLogin())
            {
                userPassBox.IsEnabled = true;
            }
            else
            {
                userPassBox.IsEnabled = false;
            }
        }

        private bool CheckLogin()
        {
            string login = userLoginTextBox.Text;

            NewLoginValidation loginValidation = new NewLoginValidation();
            CultureInfo culture = CultureInfo.InvariantCulture;

            if (loginValidation.Validate(userLoginTextBox.Text, culture) == ValidationResult.ValidResult)
            {
                return true;
            }
            return false;
        }

        public string GetPassword()
        {
            return userPassBox.Text;
        }
    }
}
