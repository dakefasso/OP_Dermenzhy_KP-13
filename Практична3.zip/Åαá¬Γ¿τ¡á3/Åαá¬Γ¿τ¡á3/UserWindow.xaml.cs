﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Практична3
{
    /// <summary>
    /// Interaction logic for UserWindow.xaml
    /// </summary>
    public partial class UserWindow : Window
    {
        public UserWindow(string login)
        {
            InitializeComponent();

            User user = PostgreExecuter.GetUser(login);
            userNameTextBox.Text = user.Name;
            userSurnameTextBox.Text = user.Surname;

            saveDataButton.IsEnabled = false;

            userNameTextBox.TextChanged += (s, e) => CheckInput();
            userSurnameTextBox.TextChanged += (s, e) => CheckInput();
            userPassBox.TextChanged += (s, e) => CheckInput();

            saveDataButton.Click += (s, e) =>
            {
                User user = new User();
                user.Name = userNameTextBox.Text;
                user.Surname = userSurnameTextBox.Text;
                user.Password = Hasher.HashPassword(userPassBox.Text);

                PostgreExecuter.UpdateUser(user, login);
                userNameTextBox.Text = userSurnameTextBox.Text = userPassBox.Text = "";
            };

            backButton.Click += (s, e) =>
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                Close();
            };
        }

        private void CheckInput()
        {
            NameValidation nameValidation = new NameValidation();
            PasswordValidation passwordValidation = new PasswordValidation();

            CultureInfo culture = CultureInfo.InvariantCulture;

            if (nameValidation.Validate(userNameTextBox.Text, culture) == ValidationResult.ValidResult &&
                nameValidation.Validate(userSurnameTextBox.Text, culture) == ValidationResult.ValidResult &&
                passwordValidation.Validate(userPassBox.Text, culture) == ValidationResult.ValidResult)
            {
                saveDataButton.IsEnabled = true;
            }
            else
            {
                saveDataButton.IsEnabled = false;
            }
        }
    }
}
