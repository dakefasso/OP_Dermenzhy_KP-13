﻿using Npgsql;

using System.Collections.Generic;
using System.IO;
using System.Windows;

namespace Практична3
{
    public class PostgreExecuter
    {
        static private NpgsqlConnection GetConnection()
        {
            try
            {
                string server = "localhost",
                database = "UserControl",
                port = "5432",
                userID = "postgres",
                password = GetPassword();

                NpgsqlConnection connection = new NpgsqlConnection($@"Server={server};Port={port};User Id={userID};Password={password};Database={database}");
                connection.Open();
                
                return connection;
            }
            catch 
            { 
                MessageBox.Show("Помилка SQL-запиту"); 
                return new NpgsqlConnection();
            }
        }

        static public void InsertUser(User user)
        {
            NpgsqlConnection connection = GetConnection();
            NpgsqlCommand command = connection.CreateCommand();

            string commandText = @"INSERT INTO users (login, password, name, surname, status, restrictions) 
                                   VALUES(@login, @password, @name, @surname, @status, @restrictions);";
            command.CommandText = Cut(commandText);

            command.Parameters.AddWithValue("login", user.Login);
            command.Parameters.AddWithValue("Password", user.Password);
            command.Parameters.AddWithValue("name", user.Name);
            command.Parameters.AddWithValue("surname", user.Surname);
            command.Parameters.AddWithValue("status", user.Status);
            command.Parameters.AddWithValue("restrictions", user.Restrictions);

            command.ExecuteNonQuery();
            connection.Close();
        }

        static public User GetUser(string login)
        {
            NpgsqlConnection connection = GetConnection();
            NpgsqlCommand command = connection.CreateCommand();

            string commandText = "SELECT * FROM users WHERE login = @login;";
            command.CommandText = Cut(commandText);
            command.Parameters.AddWithValue("login", login);

            NpgsqlDataReader reader = command.ExecuteReader();
            User user = new User();
            if (reader.Read())
            {
                user.Login = login;
                user.Password = reader.GetString(1);
                user.Name = reader.GetString(2);
                user.Surname = reader.GetString(3);
                user.Status = reader.GetBoolean(4);
                user.Restrictions = reader.GetBoolean(5);
            }
            return user;
        }

        static public string CheckLogin(string login)
        {
            NpgsqlConnection connection = GetConnection();
            NpgsqlCommand command = connection.CreateCommand();

            string commandText = "SELECT password FROM users WHERE login = @login;";
            command.CommandText = Cut(commandText);
            command.Parameters.AddWithValue("login", login);
            
            NpgsqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string password = reader.GetString(0);
                reader.Close();
                connection.Close();
                return password;
            }

            reader.Close();
            connection.Close();
            return "";
        }

        static public bool CkeckStatus(string login)
        {
            NpgsqlConnection connection = GetConnection();
            NpgsqlCommand command = connection.CreateCommand();

            string commandText = "SELECT status FROM users WHERE login = @login;";
            command.CommandText = Cut(commandText);
            command.Parameters.AddWithValue("login", login);

            NpgsqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                bool status = reader.GetBoolean(0);
                reader.Close();
                connection.Close();
                return status;
            }

            reader.Close();
            connection.Close();
            return false;
        }

        static public bool CkeckRestrictions(string login)
        {
            NpgsqlConnection connection = GetConnection();
            NpgsqlCommand command = connection.CreateCommand();

            string commandText = "SELECT restrictions FROM users WHERE login = @login;";
            command.CommandText = Cut(commandText);
            command.Parameters.AddWithValue("login", login);

            NpgsqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                bool restrictions = reader.GetBoolean(0);
                reader.Close();
                connection.Close();
                return restrictions;
            }

            reader.Close();
            connection.Close();
            return true;
        }

        static public string CheckPassword(string login)
        {
            return CheckLogin(login);
        }


        static public List<string> GetLogins()
        {
            List<string> logins = new List<string>();
            NpgsqlConnection connection = GetConnection();
            NpgsqlCommand command = connection.CreateCommand();

            string commandText = "SELECT login FROM users WHERE login <> 'ADMIN'";
            command.CommandText = Cut(commandText);

            NpgsqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string login = reader.GetString(0);
                logins.Add(login);
            }

            reader.Close();
            connection.Close();
            return logins;
        }

        static public void UpdateUser(User user, string login)
        {
            NpgsqlConnection connection = GetConnection();
            NpgsqlCommand command = connection.CreateCommand();

            if (user.Login == "ADMIN")
            {
                string commandText = "UPDATE users SET password = @password WHERE login = @login";
                command.CommandText = Cut(commandText);
                command.Parameters.AddWithValue("login", login);
                command.Parameters.AddWithValue("password", user.Password);
            }
            else
            {
                string commandText = "UPDATE users SET name = @name, surname = @surname, password = @password, restrictions = @restrictions, status = @status WHERE login = @login";
                command.CommandText = Cut(commandText);
                command.Parameters.AddWithValue("login", login);
                command.Parameters.AddWithValue("password", user.Password);
                command.Parameters.AddWithValue("name", user.Name);
                command.Parameters.AddWithValue("surname", user.Surname);
                command.Parameters.AddWithValue("restrictions", user.Restrictions);
                command.Parameters.AddWithValue("status", user.Status);
            }

            command.ExecuteNonQuery();
            connection.Close();
        }

        static public void DeleteUser(User user)
        {
            NpgsqlConnection connection = GetConnection();
            NpgsqlCommand command = connection.CreateCommand();

            string commandText = @"DELETE FROM users WHERE login = @login";
            command.CommandText = Cut(commandText);
            command.Parameters.AddWithValue("login", user.Login);

            command.ExecuteNonQuery();
            connection.Close();
        }

        static private string Cut(string text)
        {
            return text.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
        }

        static private string GetPassword()
        {
            string path = @"C:\Users\Admin\Desktop\Дз КПИ\ОП\2 семестр\Лабораторные\Лаба3\Лаба3\password.txt";
            return File.ReadAllText(path);
        }
    }
}