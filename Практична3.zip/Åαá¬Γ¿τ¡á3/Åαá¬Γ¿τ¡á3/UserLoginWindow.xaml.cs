﻿using System.Windows.Controls;
using System.Windows;
using System.Globalization;

namespace Практична3
{
    public partial class UserLoginWindow : Window
    {
        public UserLoginWindow()
        {
            int errorCounter = 0;
            InitializeComponent();

            userPassBox.IsEnabled = false;
            tryPassButton.IsEnabled = false;
            userLoginTextBox.TextChanged += (s, e) =>
            {
                LoginValidation loginValidation = new LoginValidation();
                CultureInfo culture = CultureInfo.InvariantCulture;

                if (loginValidation.Validate(userLoginTextBox.Text, culture) == ValidationResult.ValidResult)
                {
                    userPassBox.IsEnabled = true;
                }
                else
                {
                    userPassBox.IsEnabled = false;
                }
            };

            userPassBox.PasswordChanged += (s, e) =>
            {
                if (userPassBox.Password.Length != 0)
                {
                    userLoginTextBox.IsEnabled = false;
                    tryPassButton.IsEnabled = true;
                }
                else
                {
                    userLoginTextBox.IsEnabled = true;
                    tryPassButton.IsEnabled = false;
                }
                
            };

            registerButton.Click += (s, e) => OpenUserRegisterWindow();

            tryPassButton.Click += (s, e) =>
            {
                if (PostgreExecuter.CheckPassword(userLoginTextBox.Text) == Hasher.HashPassword(userPassBox.Password))
                {
                    CurrentLogin.Login = userLoginTextBox.Text;
                    UserWindow userWindow = new UserWindow(userLoginTextBox.Text);
                    userWindow.Show();
                    Close();
                }
                else
                {
                    userPassBox.Password = "";
                    if (errorCounter == 0)
                    {
                        MessageBox.Show("Неправильний пароль. Залишилося 2 спроби");
                    }
                    else if (errorCounter == 1)
                    {
                        MessageBox.Show($"Неправильний пароль. Залишилася 1 спроба");
                    }
                    else
                    {
                        Close();
                    }
                    errorCounter++;
                }
            };
        }

        private void OpenUserRegisterWindow()
        {
            UserRegisterWindow userRegisterWindow = new UserRegisterWindow();
            userRegisterWindow.Show();
            Close();
        }
    }
}
