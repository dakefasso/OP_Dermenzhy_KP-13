﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace Лаба1
{
    /// <summary>
    /// Interaction logic for CalculatorWindow.xaml
    /// </summary>
    public partial class CalculatorWindow : Window
    {
        public CalculatorWindow()
        {
            InitializeComponent();

            back.Click += (s, a) => Back();
            foreach (UIElement el in MainRoot.Children)
            {
                if (el is Button)
                {
                    ((Button)el).Click += ButtonClick;
                }
            }
        }

        private void Back()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }

        private void ButtonClick(object sender, RoutedEventArgs e)
        {
            string symbol = Convert.ToString(((Button)e.OriginalSource).Content);
            if (symbol == "=")
            {
                string result = new DataTable().Compute(text.Text, null).ToString();
                text.Text = result;
            }
            else
            {
                text.Text = symbol == "AC" ? "" : text.Text + symbol;
            }
        }
    }
}
