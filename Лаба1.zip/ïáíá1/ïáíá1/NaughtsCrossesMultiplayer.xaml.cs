﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Лаба1
{
    /// <summary>
    /// Interaction logic for NaughtsCrossesMultiplayer.xaml
    /// </summary>
    public partial class NaughtsCrossesMultiplayer : Window
    {
        int counter;
        List<Button> firstPlayerMoves = new List<Button>();
        List<Button> secondPlayerMoves = new List<Button>();
        public NaughtsCrossesMultiplayer()
        {
            InitializeComponent();

            exit.Click += (s, a) => Exit();
            newGameButton.Click += (s, a) => InitNewGame();
            NewGame();
        }

        public void InitNewGame()
        {
            NaughtsCrossesMultiplayer ncm = new NaughtsCrossesMultiplayer();
            Close();
            ncm.Show();
        }

        public void NewGame()
        {
            turnLabel.Content = "Хід першого гравця";
            counter = 0;
            firstPlayerMoves.Clear();
            secondPlayerMoves.Clear();

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button)
                {
                    el.IsEnabled = true;
                }
            }

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                {
                    ((Button)el).Click += (s, a) => NextTurn((Button)el);
                }
            }
        }
        public void NextTurn(Button button)
        {
            string symbol;

            if (counter % 2 == 0)
            {
                symbol = "X";
                firstPlayerMoves.Add(button);
                turnLabel.Content = "Хід другого гравця";
            }
            else
            {
                symbol = "O";
                secondPlayerMoves.Add(button);
                turnLabel.Content = "Хід першого гравця";
            }

            button.Content = symbol;
            counter++;

            DisableButtons(1);
            CheckResult();
        }

        public void CheckResult()
        {
            if(CheckWin(1) == true)
            {
                DisableButtons(0);
                turnLabel.Content = "Гравець 1 виграв!";
            }
            else if(CheckWin(2) == true)
            {
                DisableButtons(0);
                turnLabel.Content = "Гравець 2 виврав!";
            }
            else if(counter == 25)
            {
                DisableButtons(0);
                turnLabel.Content = "Нічия!";
            }
        }

        public bool CheckWin(int player)
        {
            bool flag1 = false, flag2 = false, flag3 = false, flag4 = false, mainflag = false;

            
            for (int i = 1; i < 6; i++)
            {
                for (int j = 1; j < 3; j++)
                {
                    //проверка по горизонтали 
                    foreach (Button el in player == 1? firstPlayerMoves: secondPlayerMoves)
                    {
                        string check1 = el.Uid.Substring(0, 1);
                        string check2 = el.Uid.Substring(1, 1);

                        if (check1 == Convert.ToString(i) && check2 == Convert.ToString(j))                      
                        {
                            flag1 = true;
                        }
                        if (check1 == Convert.ToString(i) && check2 ==  Convert.ToString(j + 1))
                        {
                            flag2 = true;
                        }
                        if (check1 == Convert.ToString(i) && check2 ==  Convert.ToString(j + 2))
                        {
                            flag3 = true;
                        }
                        if (check1 == Convert.ToString(i) && check2 ==  Convert.ToString(j + 3))
                        {
                            flag4 = true;
                        }
                        if (flag1 && flag2 && flag3 && flag4)
                        {
                            mainflag = true;
                        }
                    }

                    flag1 = flag2 = flag3 = flag4 = false;

                    //проверка по вертикали
                    foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                    {
                        string check1 = el.Uid.Substring(0, 1);
                        string check2 = el.Uid.Substring(1, 1);

                        if (check1 == Convert.ToString(j) && check2 == Convert.ToString(i))
                        {
                            flag1 = true;
                        }
                        if (check1 == Convert.ToString(j) + 1 && check2 == Convert.ToString(i))
                        {
                            flag2 = true;
                        }
                        if (check1 == Convert.ToString(j) + 2 && check2 == Convert.ToString(i))
                        {
                            flag3 = true;
                        }
                        if (check1 == Convert.ToString(j) + 3 && check2 == Convert.ToString(i))
                        {
                            flag4 = true;
                        }
                        if (flag1 && flag2 && flag3 && flag4)
                        {
                            mainflag = true;
                        }

                        flag1 = flag2 = flag3 = flag4 = false;
                    }
                }
            }

            //проверка по диагонали
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    if (j % 2 == 0)
                    {
                        foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                        {
                            string check1 = el.Uid.Substring(0, 1);
                            string check2 = el.Uid.Substring(1, 1);

                            if (check1 == Convert.ToString(1 + i) && check2 == Convert.ToString(1 + i))
                            {
                                flag1 = true;
                            }
                            if (check1 ==  Convert.ToString(2 + i) && check2 ==  Convert.ToString(2 + i))
                            {
                                flag2 = true;
                            }
                            if (check1 ==  Convert.ToString(3 + i) && check2 ==  Convert.ToString(3 + i))
                            {
                                flag3 = true;
                            }
                            if (check1 ==  Convert.ToString(4 + i) && check2 ==  Convert.ToString(4 + i))
                            {
                                flag4 = true;
                            }
                            if (flag1 && flag2 && flag3 && flag4)
                            {
                                mainflag = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                        {
                            string check1 = el.Uid.Substring(0, 1);
                            string check2 = el.Uid.Substring(1, 1);

                            if (check1 == Convert.ToString(1 + i) && check2 ==  Convert.ToString(5 - i))
                            {
                                flag1 = true;
                            }
                            if (check1 == Convert.ToString(2 + i) && check2 ==  Convert.ToString(4 - i))
                            {
                                flag2 = true;
                            }
                            if (check1 == Convert.ToString(3 + i) && check2 ==  Convert.ToString(3 - i))
                            {
                                flag3 = true;
                            }
                            if (check1 == Convert.ToString(4 + i) && check2 ==  Convert.ToString(2 - i))
                            {
                                flag4 = true;
                            }
                            if (flag1 && flag2 && flag3 && flag4)
                            {
                                mainflag = true;
                            }
                        }                    
                    }

                    flag1 = flag2 = flag3 = flag4 = false;
                }
            }

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    if (j % 2 == 0)
                    {
                        foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                        {
                            string check1 = el.Uid.Substring(0, 1);
                            string check2 = el.Uid.Substring(1, 1);

                            if (check1 == Convert.ToString(2 - i) && check2 == Convert.ToString(1 + i))
                            {
                                flag1 = true;
                            }
                            if (check1 == Convert.ToString(3 - i) && check2 == Convert.ToString(2 + i))
                            {
                                flag2 = true;
                            }
                            if (check1 == Convert.ToString(4 - i) && check2 == Convert.ToString(3 + i))
                            {
                                flag3 = true;
                            }
                            if (check1 == Convert.ToString(5 - i) && check2 == Convert.ToString(4 + i))
                            {
                                flag4 = true;
                            }
                            if (flag1 && flag2 && flag3 && flag4)
                            {
                                mainflag = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                        {
                            string check1 = el.Uid.Substring(0, 1);
                            string check2 = el.Uid.Substring(1, 1);

                            if (check1 == Convert.ToString(1 + i) && check2 == Convert.ToString(4 + i))
                            {
                                flag1 = true;
                            }
                            if (check1 == Convert.ToString(2 + i) && check2 == Convert.ToString(3 + i))
                            {
                                flag2 = true;
                            }
                            if (check1 == Convert.ToString(3 + i) && check2 == Convert.ToString(2 + i))
                            {
                                flag3 = true;
                            }
                            if (check1 == Convert.ToString(4 + i) && check2 == Convert.ToString(1 + i))
                            {
                                flag4 = true;
                            }
                            if (flag1 && flag2 && flag3 && flag4)
                            {
                                mainflag = true;
                            }
                        }
                    }

                    flag1 = flag2 = flag3 = flag4 = false;
                }
            }

            if(mainflag == true)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public void DisableButtons(int state)
        {
            if (state == 0)
            {
                foreach (UIElement el in playTable.Children)
                {
                    if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                    {
                        el.IsEnabled = false;
                    }
                }
            }
            else
            {
                foreach (Button button in firstPlayerMoves)
                {
                    button.IsEnabled = false;
                }
                foreach (Button button in secondPlayerMoves)
                {
                    button.IsEnabled = false;
                }
            }
        }

        public void Exit()
        {
            NaughtsCrossesWindow ncw = new NaughtsCrossesWindow();
            Close();
            ncw.Show();
        }
    }
}
