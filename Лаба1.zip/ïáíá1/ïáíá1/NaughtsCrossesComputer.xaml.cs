﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Threading;

namespace Лаба1
{
    /// <summary>
    /// Interaction logic for NaughtsCrossesComputer.xaml
    /// </summary>
    public partial class NaughtsCrossesComputer : Window
    {
        static Random rnd = new Random();
        DispatcherTimer t;
        string symbol;
        int counter;

        List<Button> playersMoves = new List<Button>();
        List<Button> computerMoves = new List<Button>();
        public NaughtsCrossesComputer()
        {
            InitializeComponent();
            exit.Click += (s, a) => Exit();

            NewGame();
            newGameButton.Click += (s, a) => InitNewGame();
        }

        public void InitNewGame()
        {
            NaughtsCrossesComputer ncc = new NaughtsCrossesComputer();
            Close();
            ncc.Show();
        }

        public void NewGame()
        {
            playersMoves.Clear();
            computerMoves.Clear();
            counter = 0;

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button)
                {
                    el.IsEnabled = true;

                    if ((string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                    {
                        ((Button)el).Content = "";
                    }
                }
            }

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                {
                    ((Button)el).Click += (s, a) => PlayerTurn((Button)el);
                }
            }

            if (rnd.Next() % 2 == 0)
            {
                DispatcherTimer t = new DispatcherTimer();
                t.Tick += new EventHandler(ComputerTurn);
                t.Interval = new TimeSpan(0, 0, 0, 1, 0);
                t.Start();
            }
        }

        public void Exit()
        {
            NaughtsCrossesWindow ncw = new NaughtsCrossesWindow();
            Close();
            ncw.Show();
        }

        public void PlayerTurn(Button button)
        {
            symbol = counter % 2 == 0 ? "X" : "O";
            counter++;
            button.Content = symbol;
            playersMoves.Add(button);
            turnLabel.Content = "Хід комп'ютера";

            if (CheckWin() == 1)
            {
                Result(1);
            }
            else if (CheckWin() == 0)
            {
                Result(0);
            }
            else
            {
                foreach (UIElement el in playTable.Children)
                {
                    if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                    {
                        el.IsEnabled = false;
                    }
                }
                t = new DispatcherTimer();
                t.Tick += new EventHandler(ComputerTurn);
                t.Interval = new TimeSpan(0, 0, 0, 1, 0);
                t.Start();
            }
        }

        public void Result(int result)
        {
            string text = "";
            switch (result)
            {
                case 1:
                    text = "Ви виграли!";
                    break;
                case 2:
                    text = "Виграв комп'ютер";
                    break;
                case 0:
                    text = "Нічия";
                    break;
            }

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                {
                    el.IsEnabled = false;
                }
            }
            turnLabel.Content = text;
        }

        public int CheckWin()
        {
            if (playersMoves.Contains(_11) && playersMoves.Contains(_12) && playersMoves.Contains(_13) ||
                playersMoves.Contains(_21) && playersMoves.Contains(_22) && playersMoves.Contains(_23) ||
                playersMoves.Contains(_31) && playersMoves.Contains(_32) && playersMoves.Contains(_33) ||
                playersMoves.Contains(_11) && playersMoves.Contains(_21) && playersMoves.Contains(_31) ||
                playersMoves.Contains(_12) && playersMoves.Contains(_22) && playersMoves.Contains(_32) ||
                playersMoves.Contains(_13) && playersMoves.Contains(_23) && playersMoves.Contains(_33) ||
                playersMoves.Contains(_11) && playersMoves.Contains(_22) && playersMoves.Contains(_33) ||
                playersMoves.Contains(_13) && playersMoves.Contains(_22) && playersMoves.Contains(_31))
            {
                return 1;
            }
            else if (computerMoves.Contains(_11) && computerMoves.Contains(_12) && computerMoves.Contains(_13) ||
                computerMoves.Contains(_21) && computerMoves.Contains(_22) && computerMoves.Contains(_23) ||
                computerMoves.Contains(_31) && computerMoves.Contains(_32) && computerMoves.Contains(_33) ||
                computerMoves.Contains(_11) && computerMoves.Contains(_21) && computerMoves.Contains(_31) ||
                computerMoves.Contains(_12) && computerMoves.Contains(_22) && computerMoves.Contains(_32) ||
                computerMoves.Contains(_13) && computerMoves.Contains(_23) && computerMoves.Contains(_33) ||
                computerMoves.Contains(_11) && computerMoves.Contains(_22) && computerMoves.Contains(_33) ||
                computerMoves.Contains(_13) && computerMoves.Contains(_22) && computerMoves.Contains(_31))
            {
                return 2;
            }
            else if (counter == 9)
            {
                return 0;
            }
            else
            {
                return 99999;
            }
        }

        public void ComputerTurn(object sender, EventArgs e)
        {
            Button button = _11;

            if (counter == 0)
            {
                button = _22;
            }
            else if (counter == 1)
            {
                if (playersMoves.Contains(_22))
                {
                    button = rnd.Next() % 4 == 0 ? _11 : rnd.Next() % 3 == 0 ? _13 : rnd.Next() % 2 == 0 ? _31 : _33;
                }
                else
                {
                    button = _22;
                }
            }
            else if (counter == 2)
            {
                button = rnd.Next() % 2 == 0 ? (playersMoves.Contains(_13) ? _31 : _13) : (playersMoves.Contains(_31) ? _13 : _31);
            }
            else if (counter == 3 && playersMoves.Contains(_22))
            {

                if (playersMoves.Contains(_11) && computerMoves.Contains(_33) || playersMoves.Contains(_31) && computerMoves.Contains(_13))
                {
                    button = _23;
                }
                else if (playersMoves.Contains(_13) && computerMoves.Contains(_31) || playersMoves.Contains(_33) && computerMoves.Contains(_11))
                {
                    button = _21;
                }
            }
            else
            {
                //в строку
                if (computerMoves.Contains(_11) && computerMoves.Contains(_12) && !playersMoves.Contains(_13))
                {
                    button = _13;
                }
                else if (computerMoves.Contains(_13) && computerMoves.Contains(_12) && !playersMoves.Contains(_11))
                {
                    button = _11;
                }
                else if (computerMoves.Contains(_11) && computerMoves.Contains(_13) && !playersMoves.Contains(_12))
                {
                    button = _12;
                }

                else if (computerMoves.Contains(_21) && computerMoves.Contains(_22) && !playersMoves.Contains(_23))
                {
                    button = _23;
                }
                else if (computerMoves.Contains(_23) && computerMoves.Contains(_22) && !playersMoves.Contains(_21))
                {
                    button = _21;
                }
                else if (computerMoves.Contains(_21) && computerMoves.Contains(_23) && !playersMoves.Contains(_22))
                {
                    button = _22;
                }

                else if (computerMoves.Contains(_31) && computerMoves.Contains(_32) && !playersMoves.Contains(_33))
                {
                    button = _33;
                }
                else if (computerMoves.Contains(_33) && computerMoves.Contains(_32) && !playersMoves.Contains(_31))
                {
                    button = _31;
                }
                else if (computerMoves.Contains(_31) && computerMoves.Contains(_33) && !playersMoves.Contains(_32))
                {
                    button = _32;
                }

                //в столбец
                else if (computerMoves.Contains(_11) && computerMoves.Contains(_21) && !playersMoves.Contains(_31))
                {
                    button = _31;
                }
                else if (computerMoves.Contains(_11) && computerMoves.Contains(_31) && !playersMoves.Contains(_21))
                {
                    button = _21;
                }
                else if (computerMoves.Contains(_31) && computerMoves.Contains(_21) && !playersMoves.Contains(_11))
                {
                    button = _11;
                }

                else if (computerMoves.Contains(_12) && computerMoves.Contains(_22) && !playersMoves.Contains(_32))
                {
                    button = _32;
                }
                else if (computerMoves.Contains(_12) && computerMoves.Contains(_32) && !playersMoves.Contains(_22))
                {
                    button = _22;
                }
                else if (computerMoves.Contains(_32) && computerMoves.Contains(_22) && !playersMoves.Contains(_12))
                {
                    button = _12;
                }

                else if (computerMoves.Contains(_13) && computerMoves.Contains(_23) && !playersMoves.Contains(_33))
                {
                    button = _33;
                }
                else if (computerMoves.Contains(_13) && computerMoves.Contains(_33) && !playersMoves.Contains(_23))
                {
                    button = _23;
                }
                else if (computerMoves.Contains(_33) && computerMoves.Contains(_23) && !playersMoves.Contains(_13))
                {
                    button = _13;
                }

                //по диагонали
                else if (computerMoves.Contains(_11) && computerMoves.Contains(_22) && !playersMoves.Contains(_33))
                {
                    button = _33;
                }
                else if (computerMoves.Contains(_11) && computerMoves.Contains(_33) && !playersMoves.Contains(_22))
                {
                    button = _22;
                }
                else if (computerMoves.Contains(_33) && computerMoves.Contains(_22) && !playersMoves.Contains(_11))
                {
                    button = _11;
                }

                else if (computerMoves.Contains(_13) && computerMoves.Contains(_22) && !playersMoves.Contains(_31))
                {
                    button = _31;
                }
                else if (computerMoves.Contains(_13) && computerMoves.Contains(_31) && !playersMoves.Contains(_22))
                {
                    button = _22;
                }
                else if (computerMoves.Contains(_31) && computerMoves.Contains(_22) && !playersMoves.Contains(_13))
                {
                    button = _13;
                }



                //в строку
                else if (playersMoves.Contains(_11) && playersMoves.Contains(_12) && !computerMoves.Contains(_13))
                {
                    button = _13;
                }
                else if (playersMoves.Contains(_13) && playersMoves.Contains(_12) && !computerMoves.Contains(_11))
                {
                    button = _11;
                }
                else if (playersMoves.Contains(_11) && playersMoves.Contains(_13) && !computerMoves.Contains(_12))
                {
                    button = _12;
                }

                else if (playersMoves.Contains(_21) && playersMoves.Contains(_22) && !computerMoves.Contains(_23))
                {
                    button = _23;
                }
                else if (playersMoves.Contains(_23) && playersMoves.Contains(_22) && !computerMoves.Contains(_21))
                {
                    button = _21;
                }
                else if (playersMoves.Contains(_21) && playersMoves.Contains(_23) && !computerMoves.Contains(_22))
                {
                    button = _22;
                }

                else if (playersMoves.Contains(_31) && playersMoves.Contains(_32) && !computerMoves.Contains(_33))
                {
                    button = _33;
                }
                else if (playersMoves.Contains(_33) && playersMoves.Contains(_32) && !computerMoves.Contains(_31))
                {
                    button = _31;
                }
                else if (playersMoves.Contains(_31) && playersMoves.Contains(_33) && !computerMoves.Contains(_32))
                {
                    button = _32;
                }

                //в столбец
                else if (playersMoves.Contains(_11) && playersMoves.Contains(_21) && !computerMoves.Contains(_31))
                {
                    button = _31;
                }
                else if (playersMoves.Contains(_11) && playersMoves.Contains(_31) && !computerMoves.Contains(_21))
                {
                    button = _21;
                }
                else if (playersMoves.Contains(_31) && playersMoves.Contains(_21) && !computerMoves.Contains(_11))
                {
                    button = _11;
                }

                else if (playersMoves.Contains(_12) && playersMoves.Contains(_22) && !computerMoves.Contains(_32))
                {
                    button = _32;
                }
                else if (playersMoves.Contains(_12) && playersMoves.Contains(_32) && !computerMoves.Contains(_22))
                {
                    button = _22;
                }
                else if (playersMoves.Contains(_32) && playersMoves.Contains(_22) && !computerMoves.Contains(_12))
                {
                    button = _12;
                }

                else if (playersMoves.Contains(_13) && playersMoves.Contains(_23) && !computerMoves.Contains(_33))
                {
                    button = _33;
                }
                else if (playersMoves.Contains(_13) && playersMoves.Contains(_33) && !computerMoves.Contains(_23))
                {
                    button = _23;
                }
                else if (playersMoves.Contains(_33) && playersMoves.Contains(_23) && !computerMoves.Contains(_13))
                {
                    button = _13;
                }

                //по диагонали
                else if (playersMoves.Contains(_11) && playersMoves.Contains(_22) && !computerMoves.Contains(_33))
                {
                    button = _33;
                }
                else if (playersMoves.Contains(_11) && playersMoves.Contains(_33) && !computerMoves.Contains(_22))
                {
                    button = _22;
                }
                else if (playersMoves.Contains(_33) && playersMoves.Contains(_22) && !computerMoves.Contains(_11))
                {
                    button = _11;
                }

                else if (playersMoves.Contains(_13) && playersMoves.Contains(_22) && !computerMoves.Contains(_31))
                {
                    button = _31;
                }
                else if (playersMoves.Contains(_13) && playersMoves.Contains(_31) && !computerMoves.Contains(_22))
                {
                    button = _22;
                }
                else if (playersMoves.Contains(_31) && playersMoves.Contains(_22) && !computerMoves.Contains(_13))
                {
                    button = _13;
                }


                //дефолт
                else
                {
                    if (!computerMoves.Contains(_11) && !playersMoves.Contains(_11))
                    {
                        button = _11;
                    }
                    else if (!computerMoves.Contains(_12) && !playersMoves.Contains(_12))
                    {
                        button = _12;
                    }
                    else if (!computerMoves.Contains(_13) && !playersMoves.Contains(_13))
                    {
                        button = _13;
                    }
                    else if (!computerMoves.Contains(_21) && !playersMoves.Contains(_21))
                    {
                        button = _21;
                    }
                    else if (!computerMoves.Contains(_23) && !playersMoves.Contains(_23))
                    {
                        button = _23;
                    }
                    else if (!computerMoves.Contains(_31) && !playersMoves.Contains(_31))
                    {
                        button = _31;
                    }
                    else if (!computerMoves.Contains(_32) && !playersMoves.Contains(_32))
                    {
                        button = _32;
                    }
                    else
                    {
                        button = _33;
                    }
                }
            }

            if(playersMoves.Contains(button) || computerMoves.Contains(button))
            {
                if (!computerMoves.Contains(_11) && !playersMoves.Contains(_11))
                {
                    button = _11;
                }
                else if (!computerMoves.Contains(_12) && !playersMoves.Contains(_12))
                {
                    button = _12;
                }
                else if (!computerMoves.Contains(_13) && !playersMoves.Contains(_13))
                {
                    button = _13;
                }
                else if (!computerMoves.Contains(_21) && !playersMoves.Contains(_21))
                {
                    button = _21;
                }
                else if (!computerMoves.Contains(_23) && !playersMoves.Contains(_23))
                {
                    button = _23;
                }
                else if (!computerMoves.Contains(_31) && !playersMoves.Contains(_31))
                {
                    button = _31;
                }
                else if (!computerMoves.Contains(_32) && !playersMoves.Contains(_32))
                {
                    button = _32;
                }
                else
                {
                    button = _33;
                }
            }

            symbol = counter % 2 == 0 ? "X" : "O";
            counter++;
            button.Content = symbol;
            computerMoves.Add(button);

            if (CheckWin() == 2)
            {
                Result(2);
            }
            else if (CheckWin() == 0)
            {
                Result(0);
            }
            else
            {
                turnLabel.Content = "Ваш хід";
                foreach (UIElement el in playTable.Children)
                {
                    if (el is Button && !playersMoves.Contains((Button)el) && !computerMoves.Contains((Button)el))
                    {
                        el.IsEnabled = true;
                    }
                }
            }

            t.Stop();          
        }
    }
}
































//using System;
//using System.Collections.Generic;
//using System.Windows;
//using System.Threading.Tasks;
//using System.Windows.Controls;
//using System.Windows.Threading;

//namespace Лаба1
//{
//    /// <summary>
//    /// Interaction logic for NaughtsCrossesComputer.xaml
//    /// </summary>
//    public partial class NaughtsCrossesComputer : Window
//    {
//        static Random rnd = new Random();
//        string symbol = "X";
//        int counter = 0;
//        int flag;
//        DispatcherTimer t;

//        List<Button> playersMoves = new List<Button>();
//        List<Button> computerMoves = new List<Button>();
//        public NaughtsCrossesComputer()
//        {
//            InitializeComponent();
//            exit.Click += (s, a) => Exit();

//            NewGame();
//            newGameButton.Click += (s, a) => NewGame();
//        }

//        public void NewGame()
//        {
//            playersMoves.Clear();
//            computerMoves.Clear();
//            counter = 0;
//            flag = 0;

//            foreach (UIElement el in playTable.Children)
//            {
//                if (el is Button)
//                {
//                    el.IsEnabled = true;

//                    if ((string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
//                    {
//                        ((Button)el).Content = "";
//                    }
//                }
//            }

//            if (rnd.Next() % 2 == 0)
//            {
//                PlayerTurnInit();
//            }
//            else
//            {
//                InitTimer();
//            }
//        }

//        public void Exit()
//        {
//            NaughtsCrossesWindow ncw = new NaughtsCrossesWindow();
//            Close();
//            ncw.Show();
//        }

//        public void PlayerTurnInit()
//        {
//            foreach (UIElement el in playTable.Children)
//            {
//                if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
//                {
//                    ((Button)el).Click += (s, a) => PlayerTurn((Button)el);
//                }
//            }
//        }

//        public void PlayerTurn(Button button)
//        {
//            symbol = counter % 2 == 0 ? "X" : "O";
//            counter++;
//            button.Content = symbol;
//            playersMoves.Add(button);
//            turnLabel.Content = "Хід комп'ютера";

//            if (CheckWin() == 1)
//            {
//                Result(1);
//            }
//            else if (CheckWin() == 0)
//            {
//                Result(0);
//            }
//            else
//            {
//                foreach (UIElement el in playTable.Children)
//                {
//                    if (el is Button && !playersMoves.Contains((Button)el) && !computerMoves.Contains((Button)el))
//                    {
//                        el.IsEnabled = false;
//                    }
//                }
//                InitTimer();
//            }
//        }

//        public void Result(int result)
//        {
//            string text = "";
//            switch (result)
//            {
//                case 1:
//                    text = "Ви виграли!";
//                    break;
//                case 2:
//                    text = "Виграв комп'ютер";
//                    break;
//                case 0:
//                    text = "Нічия";
//                    break;
//            }

//            foreach (UIElement el in playTable.Children)
//            {
//                if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
//                {
//                    el.IsEnabled = false;
//                }
//            }
//            turnLabel.Content = text;
//        }

//        public int CheckWin()
//        {
//            if (playersMoves.Contains(_11) && playersMoves.Contains(_12) && playersMoves.Contains(_13) ||
//                playersMoves.Contains(_21) && playersMoves.Contains(_22) && playersMoves.Contains(_23) ||
//                playersMoves.Contains(_31) && playersMoves.Contains(_32) && playersMoves.Contains(_33) ||
//                playersMoves.Contains(_11) && playersMoves.Contains(_21) && playersMoves.Contains(_31) ||
//                playersMoves.Contains(_12) && playersMoves.Contains(_22) && playersMoves.Contains(_32) ||
//                playersMoves.Contains(_13) && playersMoves.Contains(_23) && playersMoves.Contains(_33) ||
//                playersMoves.Contains(_11) && playersMoves.Contains(_22) && playersMoves.Contains(_33) ||
//                playersMoves.Contains(_13) && playersMoves.Contains(_22) && playersMoves.Contains(_31))
//            {
//                return 1;
//            }
//            else if (computerMoves.Contains(_11) && computerMoves.Contains(_12) && computerMoves.Contains(_13) ||
//                computerMoves.Contains(_21) && computerMoves.Contains(_22) && computerMoves.Contains(_23) ||
//                computerMoves.Contains(_31) && computerMoves.Contains(_32) && computerMoves.Contains(_33) ||
//                computerMoves.Contains(_11) && computerMoves.Contains(_21) && computerMoves.Contains(_31) ||
//                computerMoves.Contains(_12) && computerMoves.Contains(_22) && computerMoves.Contains(_32) ||
//                computerMoves.Contains(_13) && computerMoves.Contains(_23) && computerMoves.Contains(_33) ||
//                computerMoves.Contains(_11) && computerMoves.Contains(_22) && computerMoves.Contains(_33) ||
//                computerMoves.Contains(_13) && computerMoves.Contains(_22) && computerMoves.Contains(_31))
//            {
//                return 2;
//            }
//            else if (counter == 8)
//            {
//                return 0;
//            }
//            else
//            {
//                return 99999;
//            }
//        }

//        public void ComputerTurn(object sender, EventArgs e)
//        {
//            Button button = _11;

//            if (counter == 0)
//            {
//                button = _22;
//            }
//            else if (counter == 1)
//            {
//                if (playersMoves.Contains(_22))
//                {
//                    button = rnd.Next() % 4 == 0 ? _11 : rnd.Next() % 3 == 0 ? _13 : rnd.Next() % 2 == 0 ? _31 : _33;
//                }
//                else
//                {
//                    button = _22;
//                }
//            }
//            else if (counter == 2)
//            {
//                button = rnd.Next() % 2 == 0 ? (playersMoves.Contains(_13) ? _31 : _13) : (playersMoves.Contains(_31) ? _13 : _31);
//            }
//            else if (counter == 3 && playersMoves.Contains(_22))
//            {

//                if (playersMoves.Contains(_11) && computerMoves.Contains(_33) || playersMoves.Contains(_31) && computerMoves.Contains(_13))
//                {
//                    button = _23;
//                }
//                else if (playersMoves.Contains(_13) && computerMoves.Contains(_31) || playersMoves.Contains(_33) && computerMoves.Contains(_11))
//                {
//                    button = _21;
//                }
//            }
//            else
//            {
//                //в строку
//                if (computerMoves.Contains(_11) && computerMoves.Contains(_12) && !playersMoves.Contains(_13))
//                {
//                    button = _13;
//                }
//                else if (computerMoves.Contains(_13) && computerMoves.Contains(_12) && !playersMoves.Contains(_11))
//                {
//                    button = _11;
//                }
//                else if (computerMoves.Contains(_11) && computerMoves.Contains(_13) && !playersMoves.Contains(_12))
//                {
//                    button = _12;
//                }

//                else if (computerMoves.Contains(_21) && computerMoves.Contains(_22) && !playersMoves.Contains(_23))
//                {
//                    button = _23;
//                }
//                else if (computerMoves.Contains(_23) && computerMoves.Contains(_22) && !playersMoves.Contains(_21))
//                {
//                    button = _21;
//                }
//                else if (computerMoves.Contains(_21) && computerMoves.Contains(_23) && !playersMoves.Contains(_22))
//                {
//                    button = _22;
//                }

//                else if (computerMoves.Contains(_31) && computerMoves.Contains(_32) && !playersMoves.Contains(_33))
//                {
//                    button = _33;
//                }
//                else if (computerMoves.Contains(_33) && computerMoves.Contains(_32) && !playersMoves.Contains(_31))
//                {
//                    button = _31;
//                }
//                else if (computerMoves.Contains(_31) && computerMoves.Contains(_33) && !playersMoves.Contains(_32))
//                {
//                    button = _32;
//                }

//                //в столбец
//                else if (computerMoves.Contains(_11) && computerMoves.Contains(_21) && !playersMoves.Contains(_31))
//                {
//                    button = _31;
//                }
//                else if (computerMoves.Contains(_11) && computerMoves.Contains(_31) && !playersMoves.Contains(_21))
//                {
//                    button = _21;
//                }
//                else if (computerMoves.Contains(_31) && computerMoves.Contains(_21) && !playersMoves.Contains(_11))
//                {
//                    button = _11;
//                }

//                else if (computerMoves.Contains(_12) && computerMoves.Contains(_22) && !playersMoves.Contains(_32))
//                {
//                    button = _32;
//                }
//                else if (computerMoves.Contains(_12) && computerMoves.Contains(_32) && !playersMoves.Contains(_22))
//                {
//                    button = _22;
//                }
//                else if (computerMoves.Contains(_32) && computerMoves.Contains(_22) && !playersMoves.Contains(_12))
//                {
//                    button = _12;
//                }

//                else if (computerMoves.Contains(_13) && computerMoves.Contains(_23) && !playersMoves.Contains(_33))
//                {
//                    button = _33;
//                }
//                else if (computerMoves.Contains(_13) && computerMoves.Contains(_33) && !playersMoves.Contains(_23))
//                {
//                    button = _23;
//                }
//                else if (computerMoves.Contains(_33) && computerMoves.Contains(_23) && !playersMoves.Contains(_13))
//                {
//                    button = _13;
//                }

//                //по диагонали
//                else if (computerMoves.Contains(_11) && computerMoves.Contains(_22) && !playersMoves.Contains(_33))
//                {
//                    button = _33;
//                }
//                else if (computerMoves.Contains(_11) && computerMoves.Contains(_33) && !playersMoves.Contains(_22))
//                {
//                    button = _22;
//                }
//                else if (computerMoves.Contains(_33) && computerMoves.Contains(_22) && !playersMoves.Contains(_11))
//                {
//                    button = _11;
//                }

//                else if (computerMoves.Contains(_13) && computerMoves.Contains(_22) && !playersMoves.Contains(_31))
//                {
//                    button = _31;
//                }
//                else if (computerMoves.Contains(_13) && computerMoves.Contains(_31) && !playersMoves.Contains(_22))
//                {
//                    button = _22;
//                }
//                else if (computerMoves.Contains(_31) && computerMoves.Contains(_22) && !playersMoves.Contains(_13))
//                {
//                    button = _13;
//                }



//                //в строку
//                else if (playersMoves.Contains(_11) && playersMoves.Contains(_12) && !computerMoves.Contains(_13))
//                {
//                    button = _13;
//                }
//                else if (playersMoves.Contains(_13) && playersMoves.Contains(_12) && !computerMoves.Contains(_11))
//                {
//                    button = _11;
//                }
//                else if (playersMoves.Contains(_11) && playersMoves.Contains(_13) && !computerMoves.Contains(_12))
//                {
//                    button = _12;
//                }

//                else if (playersMoves.Contains(_21) && playersMoves.Contains(_22) && !computerMoves.Contains(_23))
//                {
//                    button = _23;
//                }
//                else if (playersMoves.Contains(_23) && playersMoves.Contains(_22) && !computerMoves.Contains(_21))
//                {
//                    button = _21;
//                }
//                else if (playersMoves.Contains(_21) && playersMoves.Contains(_23) && !computerMoves.Contains(_22))
//                {
//                    button = _22;
//                }

//                else if (playersMoves.Contains(_31) && playersMoves.Contains(_32) && !computerMoves.Contains(_33))
//                {
//                    button = _33;
//                }
//                else if (playersMoves.Contains(_33) && playersMoves.Contains(_32) && !computerMoves.Contains(_31))
//                {
//                    button = _31;
//                }
//                else if (playersMoves.Contains(_31) && playersMoves.Contains(_33) && !computerMoves.Contains(_32))
//                {
//                    button = _32;
//                }

//                //в столбец
//                else if (playersMoves.Contains(_11) && playersMoves.Contains(_21) && !computerMoves.Contains(_31))
//                {
//                    button = _31;
//                }
//                else if (playersMoves.Contains(_11) && playersMoves.Contains(_31) && !computerMoves.Contains(_21))
//                {
//                    button = _21;
//                }
//                else if (playersMoves.Contains(_31) && playersMoves.Contains(_21) && !computerMoves.Contains(_11))
//                {
//                    button = _11;
//                }

//                else if (playersMoves.Contains(_12) && playersMoves.Contains(_22) && !computerMoves.Contains(_32))
//                {
//                    button = _32;
//                }
//                else if (playersMoves.Contains(_12) && playersMoves.Contains(_32) && !computerMoves.Contains(_22))
//                {
//                    button = _22;
//                }
//                else if (playersMoves.Contains(_32) && playersMoves.Contains(_22) && !computerMoves.Contains(_12))
//                {
//                    button = _12;
//                }

//                else if (playersMoves.Contains(_13) && playersMoves.Contains(_23) && !computerMoves.Contains(_33))
//                {
//                    button = _33;
//                }
//                else if (playersMoves.Contains(_13) && playersMoves.Contains(_33) && !computerMoves.Contains(_23))
//                {
//                    button = _23;
//                }
//                else if (playersMoves.Contains(_33) && playersMoves.Contains(_23) && !computerMoves.Contains(_13))
//                {
//                    button = _13;
//                }

//                //по диагонали
//                else if (playersMoves.Contains(_11) && playersMoves.Contains(_22) && !computerMoves.Contains(_33))
//                {
//                    button = _33;
//                }
//                else if (playersMoves.Contains(_11) && playersMoves.Contains(_33) && !computerMoves.Contains(_22))
//                {
//                    button = _22;
//                }
//                else if (playersMoves.Contains(_33) && playersMoves.Contains(_22) && !computerMoves.Contains(_11))
//                {
//                    button = _11;
//                }

//                else if (playersMoves.Contains(_13) && playersMoves.Contains(_22) && !computerMoves.Contains(_31))
//                {
//                    button = _31;
//                }
//                else if (playersMoves.Contains(_13) && playersMoves.Contains(_31) && !computerMoves.Contains(_22))
//                {
//                    button = _22;
//                }
//                else if (playersMoves.Contains(_31) && playersMoves.Contains(_22) && !computerMoves.Contains(_13))
//                {
//                    button = _13;
//                }


//                //дефолт
//                else
//                {
//                    if (!computerMoves.Contains(_11) && !playersMoves.Contains(_11))
//                    {
//                        button = _11;
//                    }
//                    else if (!computerMoves.Contains(_12) && !playersMoves.Contains(_12))
//                    {
//                        button = _12;
//                    }
//                    else if (!computerMoves.Contains(_13) && !playersMoves.Contains(_13))
//                    {
//                        button = _13;
//                    }
//                    else if (!computerMoves.Contains(_21) && !playersMoves.Contains(_21))
//                    {
//                        button = _21;
//                    }
//                    else if (!computerMoves.Contains(_23) && !playersMoves.Contains(_23))
//                    {
//                        button = _23;
//                    }
//                    else if (!computerMoves.Contains(_31) && !playersMoves.Contains(_31))
//                    {
//                        button = _31;
//                    }
//                    else if (!computerMoves.Contains(_32) && !playersMoves.Contains(_32))
//                    {
//                        button = _32;
//                    }
//                    else
//                    {
//                        button = _33;
//                    }
//                }
//            }

//            symbol = counter % 2 == 0 ? "X" : "O";
//            counter++;
//            button.Content = symbol;
//            computerMoves.Add(button);

//            flag++;
//            if (flag == 1)
//            {
//                t.Stop();
//            }
//        }

//        private void InitTimer()
//        {
//            flag = 0;
//            t = new DispatcherTimer();
//            t.Tick += new EventHandler(ComputerTurn);
//            t.Interval = new TimeSpan(0, 0, 0, 1, 0);
//            t.Start();

//            if (CheckWin() == 2)
//            {
//                Result(2);
//            }
//            else if (CheckWin() == 0)
//            {
//                Result(0);
//            }
//            else
//            {
//                turnLabel.Content = "Ваш хід";
//                foreach (UIElement el in playTable.Children)
//                {
//                    if (el is Button && !playersMoves.Contains((Button)el) && !computerMoves.Contains((Button)el))
//                    {
//                        el.IsEnabled = true;
//                    }
//                }
//                PlayerTurnInit();
//            }
//        }
//    }
//}