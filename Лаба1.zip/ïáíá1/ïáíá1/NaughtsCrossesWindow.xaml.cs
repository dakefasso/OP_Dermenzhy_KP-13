﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Лаба1
{
    /// <summary>
    /// Interaction logic for NaughtsCrossesWindow.xaml
    /// </summary>
    public partial class NaughtsCrossesWindow : Window
    {
        public NaughtsCrossesWindow()
        {
            InitializeComponent();
            exit.Click += (s, a) => Exit();
            computer.Click += (s, a) => Computer();
            multiplayer.Click += (s, a) => Multiplayer();
        }

        public void Computer()
        {
            NaughtsCrossesComputer ncc = new NaughtsCrossesComputer();
            Close();
            ncc.Show();
        }

        public void Multiplayer()
        {
            NaughtsCrossesMultiplayer ncm = new NaughtsCrossesMultiplayer();
            Close();
            ncm.Show();
        }

        public void Exit()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }
    }
}
