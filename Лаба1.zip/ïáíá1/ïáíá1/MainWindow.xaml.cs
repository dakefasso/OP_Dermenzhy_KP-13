﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Лаба1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
            exit.Click += (s, a) => Close();
            toData.Click += (s, a) => ToData();
            toCalculator.Click += (s, a) => ToCalculator();
            toAuthor.Click += (s, a) => ToAuthor();
            toNaughtsCrosses.Click += (s, a) => ToNaughtsCrosses();
        }

        private void ToData()
        {
            DataWindow dw = new DataWindow();
            Close();
            dw.Show();
        }

        private void ToCalculator()
        {
            CalculatorWindow cw = new CalculatorWindow();
            Close();
            cw.Show();
        }

        private void ToAuthor()
        {
            AuthorWindow aw = new AuthorWindow();
            Close();
            aw.Show();
        }

        private void ToNaughtsCrosses()
        {
            NaughtsCrossesWindow ncw = new NaughtsCrossesWindow();
            Close();
            ncw.Show();
        }
    }
}
