﻿using System.IO;
using System.Windows;
using System.Data.SQLite;
using System.Threading;
using Npgsql;

namespace Лаба1
{
    /// <summary>
    /// Interaction logic for DataWindow.xaml
    /// </summary>
    /// 
    public class Student
    {
        public int StudentKey { get; set; }
        public string FullName { get; set; }
        public string Faculty { get; set; }
        public string Group { get; set; }

        public Student(int key, string fullName, string faculty, string group)
        {
            StudentKey = key;
            FullName = fullName;
            Faculty = faculty;
            Group = group;
        }
        public Student(){}
    }
    public partial class DataWindow : Window
    {
        public DataWindow()
        {
            InitializeComponent();
            back.Click += (s, a) => Back();
            AddStudentButton.Click += (s, a) => AddStudent();
            FindStudentButton.Click += (s, a) => FindStudent();
            DeleteStudentButton.Click += (s, a) => DeleteStudent();

            AddStudentButton.IsEnabled = false;
            DeleteStudentButton.IsEnabled = false;
            FindStudentButton.IsEnabled = false;

            StudentKeyResult.IsEnabled = false;
            FullNameResult.IsEnabled = false;
            FacultyResult.IsEnabled = false;
            GroupResult.IsEnabled = false;

            Faculty.TextChanged += (s, a) => CheckAdd();
            StudentKey.TextChanged += (s, a) => CheckAdd();
            FullName.TextChanged += (s, a) => CheckAdd();
            Group.TextChanged += (s, a) => CheckAdd();
            StudentKeyDel.TextChanged += (s, a) => CheckFind();
            FullNameDel.TextChanged += (s, a) => CheckFind();
        }

        private void CheckAdd()
        {
            AddStudentButton.IsEnabled = Faculty.Text == "" || StudentKey.Text.Length != 6 || StudentKey.Text == "" || FullName.Text == "" || Group.Text == "" ? false : true;
        }

        private void CheckFind()
        {
            FindStudentButton.IsEnabled = StudentKeyDel.Text == "" && FullNameDel.Text == "" || StudentKeyDel.Text.Length != 6 ? false : true;
        }

        private void Back()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }

        private void AddStudent()
        {
            Student student = new Student(int.Parse(StudentKey.Text), FullName.Text, Faculty.Text, Group.Text);

            NpgsqlConnection connection = new NpgsqlConnection($@"Server=localhost;Port=5432;User Id=postgres;Password=25614;Database=Laba1");
            connection.Open();
            NpgsqlCommand command = connection.CreateCommand();

            command.CommandText = @$"INSERT INTO students (student_key, full_name, faculty, student_group) 
                              VALUES (@key, @name, @faculty, @group)";
            command.Parameters.AddWithValue("name", student.FullName);
            command.Parameters.AddWithValue("key", student.StudentKey);
            command.Parameters.AddWithValue("faculty", student.Faculty);
            command.Parameters.AddWithValue("group", student.Group);

            FullName.Text = null;
            StudentKey.Text = null;
            Faculty.Text = null;
            Group.Text = null;

            command.ExecuteScalar();
            connection.Close();
        }

        private Student FindStudent()
        {
            int studentKey = int.Parse(StudentKeyDel.Text);
            string fullName = FullNameDel.Text;

            NpgsqlConnection connection = new NpgsqlConnection($@"Server=localhost;Port=5432;User Id=postgres;Password=25614;Database=Laba1");
            connection.Open();
            NpgsqlCommand command = connection.CreateCommand();

            command.CommandText = @$"SELECT * FROM students WHERE student_key = @key OR full_name = @fullName";
            command.Parameters.AddWithValue("key", studentKey);
            command.Parameters.AddWithValue("fullName", fullName);

            NpgsqlDataReader reader = command.ExecuteReader();
            Student student = new Student();
            if (reader.Read())
            {
                student = GetStudent(reader);
                ShowStudentData(student);
                DeleteStudentButton.IsEnabled = true;
            }
            else
            {
                StudentNotFound();
            }

            return student;

            reader.Close();
            connection.Close();         
        }

        private Student GetStudent(NpgsqlDataReader reader)
        {
            Student student = new Student();
            student.StudentKey = reader.GetInt32(0);
            student.FullName = reader.GetString(1);
            student.Faculty = reader.GetString(2);
            student.Group = reader.GetString(3);

            return student;
        }

        private void ShowStudentData(Student student)
        {
            StudentKeyResult.Text = student.StudentKey.ToString();
            FacultyResult.Text = student.Faculty;
            GroupResult.Text = student.Group;
            FullNameResult.Text = student.FullName;
        }

        private void StudentNotFound()
        {
            StudentKeyResult.Text = "Не знайдено";
            FacultyResult.Text = "Не знайдено";
            GroupResult.Text = "Не знайдено";
            FullNameResult.Text = "Не знайдено";
        }

        private void DeleteStudent()
        {
            Student student = FindStudent();

            NpgsqlConnection connection = new NpgsqlConnection($@"Server=localhost;Port=5432;User Id=postgres;Password=25614;Database=Laba1");
            connection.Open();
            NpgsqlCommand command = connection.CreateCommand();

            command.CommandText = @$"DELETE FROM students * WHERE full_name = @name OR student_key = @key";
            command.Parameters.AddWithValue("name", student.FullName);
            command.Parameters.AddWithValue("key", student.StudentKey);

            command.ExecuteScalar();
            connection.Close();

            StudentKeyResult.Text = "Видалено";
            FacultyResult.Text = "Видалено";
            GroupResult.Text = "Видалено";
            FullNameResult.Text = "Видалено";

            DeleteStudentButton.IsEnabled = false;
        }
    }
}
