﻿using System.Windows.Media;
using System.Windows;
using System.Windows.Controls;
using System;
using System.Data;

namespace Лабораторная2
{
    /// <summary>
    /// Interaction logic for CalculatorWindow.xaml
    /// </summary>
    public partial class CalculatorWindow : Window
    {
        TextBlock text;
        public CalculatorWindow()
        {
            InitializeComponent();

            InitControls();

            //foreach (UIElement el in MainRoot.Children)
            //{
            //    if (el is Button)
            //    {
            //        ((Button)el).Click += ButtonClick;
            //    }
            //}
        }

        private void InitControls()
        {
            Title = "Калькулятор";
            Height = 350;
            Width = 500;
            ResizeMode = ResizeMode.NoResize;

            Grid myGrid = new Grid();

            RowDefinition[] rows = new RowDefinition[7];
            ColumnDefinition[] cols = new ColumnDefinition[6];

            for (int i = 0; i < 7; i++)
            {
                rows[i] = new RowDefinition();
                myGrid.RowDefinitions.Add(rows[i]);
                if (i == 6)
                {
                    rows[i].Height = new GridLength(0.05, GridUnitType.Star);
                }
            }
            for (int i = 0; i < 6; i++)
            {
                cols[i] = new ColumnDefinition();
                myGrid.ColumnDefinitions.Add(cols[i]);
                if (i == 0 || i == 5)
                {
                    cols[i].Width = new GridLength(0.05, GridUnitType.Star);
                }
            }

            Button back = new Button();
            back.Content = "Назад";
            back.HorizontalAlignment = HorizontalAlignment.Left;
            back.VerticalAlignment = VerticalAlignment.Top;
            back.Height = 40;
            back.Width = 80;
            back.Padding = new Thickness(5, 5, 5, 5);
            back.Margin = new Thickness(10, 8, 5, 5);
            back.FontSize = 20;
            back.FontFamily = new FontFamily("Comic Sans MS");
            back.FontWeight = FontWeights.Bold;

            back.Click += (s, a) => Back();

            Grid.SetRow(back, 0);
            Grid.SetColumn(back, 1);
            myGrid.Children.Add(back);


            Label label = new Label();
            label.Content = "Калькулятор";
            label.HorizontalAlignment = HorizontalAlignment.Center;
            label.VerticalAlignment = VerticalAlignment.Center;
            label.FontSize = 30;
            label.FontFamily = new FontFamily("Comic Sans MS");
            label.FontWeight = FontWeights.Bold;

            Grid.SetRow(label, 0);
            Grid.SetColumn(label, 2);
            Grid.SetColumnSpan(label, 2);
            myGrid.Children.Add(label);


            text = new TextBlock();
            text.HorizontalAlignment = HorizontalAlignment.Center;
            text.VerticalAlignment = VerticalAlignment.Center;
            text.FontSize = 25;
            text.FontFamily = new FontFamily("Comic Sans MS");
            text.FontWeight = FontWeights.Bold;

            Grid.SetRow(text, 1);
            Grid.SetColumnSpan(text, 6);
            myGrid.Children.Add(text);


            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Button button = new Button();
                    button.Height = 58;
                    button.FontFamily = new FontFamily("Comic Sans MS");
                    button.FontWeight = FontWeights.Bold;

                    button.VerticalContentAlignment = VerticalAlignment.Center;
                    button.HorizontalContentAlignment = HorizontalAlignment.Center;

                    if (i < 3 && j < 3)
                    {
                        button.Content = i * 3 + j + 1;
                        button.FontSize = 25;
                    }
                    else if (j == 3)
                    {
                        if (i == 0)
                        {
                            button.Content = "+";
                            button.FontSize = 30;
                        }
                        else if (i == 1)
                        {
                            button.Content = "-";
                            button.FontSize = 30;
                        }
                        else if (i == 2)
                        {
                            button.Content = "*";
                            button.FontSize = 30;
                        }
                        else
                        {
                            button.Content = "/";
                            button.FontSize = 25;
                        }
                    }
                    else
                    {
                        if (j == 0)
                        {
                            button.Content = 0;
                            button.FontSize = 25;
                        }
                        else if (j == 1)
                        {
                            button.Content = "=";
                            button.FontSize = 35;
                        }
                        else
                        {
                            button.Content = "AC";
                            button.FontSize = 28;
                        }
                    }

                    Grid.SetRow(button, 2 + i);
                    Grid.SetColumn(button, 1 + j);
                    myGrid.Children.Add(button);
                }
            }

            foreach (UIElement el in myGrid.Children)
            {
                if (el is Button)
                {
                    ((Button)el).Click += ButtonClick;
                }
            }

            Content = myGrid;
            Show();
        }

        private void Back()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }

        private void ButtonClick(object sender, RoutedEventArgs e)
        {
            string symbol = Convert.ToString(((Button)e.OriginalSource).Content);
            if (symbol == "=")
            {
                string result = new DataTable().Compute(text.Text, null).ToString();
                text.Text = result;
            }
            else
            {
                text.Text = symbol == "AC" ? "" : text.Text + symbol;
            }
        }
    }
}
