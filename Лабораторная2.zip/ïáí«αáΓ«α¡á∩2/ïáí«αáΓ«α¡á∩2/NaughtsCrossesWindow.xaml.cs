﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Лабораторная2
{
    /// <summary>
    /// Interaction logic for NaughtsCrossesWindow.xaml
    /// </summary>
    public partial class NaughtsCrossesWindow : Window
    {
        Grid myGrid;
        BrushConverter bc = new BrushConverter();
        public NaughtsCrossesWindow()
        {
            InitializeComponent();
            InitControls();
        }

        private void InitControls()
        {
            myGrid = new Grid();
            myGrid.Background = (Brush)bc.ConvertFrom("#FF673AB7");
            myGrid.Margin = new Thickness(10, 10, 10, 10);
            RowDefinition[] rows = new RowDefinition[8];
            ColumnDefinition[] cols = new ColumnDefinition[2];

            for (int i = 0; i < 4; i++)
            {
                rows[i] = new RowDefinition();
                myGrid.RowDefinitions.Add(rows[i]);
            }
            for (int i = 0; i < 2; i++)
            {
                cols[i] = new ColumnDefinition();
                myGrid.ColumnDefinitions.Add(cols[i]);
            }

            CreateTitle();
            CreateComputerButton();
            CreateMultiplayerButton();
            CreateStatisticsButton();
            CreateExitButton();

            Content = myGrid;
            Show();
        }

        private void CreateTitle()
        {
            Label windowTitle = new Label();
            windowTitle.HorizontalAlignment = HorizontalAlignment.Center;
            windowTitle.VerticalAlignment = VerticalAlignment.Bottom;
            windowTitle.FontSize = 25;
            windowTitle.FontFamily = new FontFamily("Comic Sans MS");
            windowTitle.FontWeight = FontWeights.Bold;
            windowTitle.Content = "Нова гра з";
            windowTitle.Foreground = Brushes.White;

            Grid.SetColumnSpan(windowTitle, 2);
            myGrid.Children.Add(windowTitle);
        }

        private void CreateComputerButton()
        {
            Button computer = new Button();
            computer.HorizontalAlignment = HorizontalAlignment.Right;
            computer.VerticalAlignment = VerticalAlignment.Bottom;
            computer.Height = 40;
            computer.Width = 180;
            computer.Margin = new Thickness(10, 10, 10, 10);
            computer.FontSize = 20;
            computer.FontFamily = new FontFamily("Comic Sans MS");
            computer.FontWeight = FontWeights.Bold;
            computer.Content = "Комп'ютером";
            computer.Background = (Brush)bc.ConvertFrom("#FF5420B0");

            Grid.SetRow(computer, 1);
            myGrid.Children.Add(computer);

            computer.Click += (s, a) => Computer();
        }

        private void CreateMultiplayerButton()
        {
            Button multiplayer = new Button();
            multiplayer.HorizontalAlignment = HorizontalAlignment.Left;
            multiplayer.VerticalAlignment = VerticalAlignment.Bottom;
            multiplayer.Height = 40;
            multiplayer.Width = 180;
            multiplayer.Margin = new Thickness(10, 10, 10, 10);
            multiplayer.FontSize = 20;
            multiplayer.FontFamily = new FontFamily("Comic Sans MS");
            multiplayer.FontWeight = FontWeights.Bold;
            multiplayer.Content = "Другом";
            multiplayer.Background = (Brush)bc.ConvertFrom("#FF5420B0");

            Grid.SetColumn(multiplayer, 1);
            Grid.SetRow(multiplayer, 1);
            myGrid.Children.Add(multiplayer);

            multiplayer.Click += (s, a) => Multiplayer();
        }

        private void CreateStatisticsButton()
        {
            Button statistics = new Button();
            statistics.HorizontalAlignment = HorizontalAlignment.Center;
            statistics.VerticalAlignment = VerticalAlignment.Center;
            statistics.Height = 40;
            statistics.Width = 140;
            statistics.FontSize = 20;
            statistics.FontFamily = new FontFamily("Comic Sans MS");
            statistics.FontWeight = FontWeights.Bold;
            statistics.Content = "Статистика";
            statistics.Background = (Brush)bc.ConvertFrom("#FF5420B0");

            Grid.SetColumnSpan(statistics, 2);
            Grid.SetRow(statistics, 2);
            myGrid.Children.Add(statistics);
        }

        private void CreateExitButton()
        {
            Button exit = new Button();
            exit.HorizontalAlignment = HorizontalAlignment.Center;
            exit.VerticalAlignment = VerticalAlignment.Top;
            exit.Height = 40;
            exit.Width = 140;
            exit.FontSize = 20;
            exit.FontFamily = new FontFamily("Comic Sans MS");
            exit.FontWeight = FontWeights.Bold;
            exit.Content = "Вийти";
            exit.Background = (Brush)bc.ConvertFrom("#FF5420B0");

            Grid.SetColumnSpan(exit, 2);
            Grid.SetRow(exit, 3);
            myGrid.Children.Add(exit);

            exit.Click += (s, a) => Exit();
        }

        private void Computer()
        {
            NaughtsCrossesComputer ncc = new NaughtsCrossesComputer();
            Close();
            ncc.Show();
        }

        private void Multiplayer()
        {
            NaughtsCrossesMultiplayer ncm = new NaughtsCrossesMultiplayer();
            Close();
            ncm.Show();
        }

        private void Exit()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }
    }
}
