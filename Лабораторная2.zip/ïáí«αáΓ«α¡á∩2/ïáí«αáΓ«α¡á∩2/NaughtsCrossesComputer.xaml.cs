﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Лабораторная2
{
    /// <summary>
    /// Interaction logic for NaughtsCrossesComputer.xaml
    /// </summary>
    public partial class NaughtsCrossesComputer : Window
    {
        static Random rnd = new Random();
        DispatcherTimer t;
        string symbol;
        int counter;
        Grid playTable;
        BrushConverter bc = new BrushConverter();
        Label turnLabel;
        Button[,] gameTable;

        List<Button> playersMoves = new List<Button>();
        List<Button> computerMoves = new List<Button>();
        public NaughtsCrossesComputer()
        {
            InitializeComponent();
            InitControls();

            NewGame();
        }

        private void InitControls()
        {
            playTable = new Grid();
            playTable.Background = (Brush)bc.ConvertFrom("#FF673AB7");
            playTable.Margin = new Thickness(10, 10, 10, 10);
            RowDefinition[] rows = new RowDefinition[7];
            ColumnDefinition[] cols = new ColumnDefinition[7];

            for (int i = 0; i < 5; i++)
            {
                rows[i] = new RowDefinition();
                if (i == 4)
                {
                    rows[i].Height = new GridLength(100);
                }
                playTable.RowDefinitions.Add(rows[i]);
            }
            for (int i = 0; i < 5; i++)
            {
                cols[i] = new ColumnDefinition();
                if (i > 0 && i < 4)
                {
                    cols[i].Width = new GridLength(115);
                }
                playTable.ColumnDefinitions.Add(cols[i]);
            }

            CreateExitButton();
            CreateNewGameButton();
            CreateTurnLabel();
            CreateGameTable();

            Content = playTable;
            Show();
        }

        private void CreateExitButton()
        {
            Button back = new Button();
            back.Content = "";
            back.HorizontalAlignment = HorizontalAlignment.Left;
            back.VerticalAlignment = VerticalAlignment.Top;
            back.HorizontalContentAlignment = HorizontalAlignment.Center;
            back.Height = 40;
            back.Width = 90;
            back.Margin = new Thickness(5, 5, 5, 5);
            back.Content = "Назад";
            back.FontSize = 20;
            back.FontFamily = new FontFamily("Comic Sans MS");
            back.FontWeight = FontWeights.Bold;
            back.Background = (Brush)bc.ConvertFrom("#FF5420B0");

            Grid.SetColumnSpan(back, 2);
            playTable.Children.Add(back);

            back.Click += (s, a) => Exit();
        }

        private void CreateNewGameButton()
        {
            Button newGame = new Button();
            newGame.Content = "Нова гра";
            newGame.HorizontalAlignment = HorizontalAlignment.Center;
            newGame.VerticalAlignment = VerticalAlignment.Top;
            newGame.HorizontalContentAlignment = HorizontalAlignment.Center;
            newGame.Height = 50;
            newGame.Width = 200;
            newGame.Margin = new Thickness(15, 15, 15, 15);
            newGame.FontSize = 30;
            newGame.FontFamily = new FontFamily("Comic Sans MS");
            newGame.FontWeight = FontWeights.Bold;
            newGame.Background = (Brush)bc.ConvertFrom("#FF300A74");
            newGame.Foreground = Brushes.White;

            Grid.SetColumn(newGame, 1);
            Grid.SetColumnSpan(newGame, 3);
            Grid.SetRow(newGame, 4);
            playTable.Children.Add(newGame);

            newGame.Click += (s, a) => InitNewGame();
        }

        private void CreateTurnLabel()
        {
            turnLabel = new Label();
            turnLabel.Content = "Ваш хід";
            turnLabel.HorizontalAlignment = HorizontalAlignment.Center;
            turnLabel.VerticalAlignment = VerticalAlignment.Center;
            turnLabel.FontSize = 30;
            turnLabel.FontFamily = new FontFamily("Comic Sans MS");
            turnLabel.FontWeight = FontWeights.Bold;
            turnLabel.Foreground = Brushes.White;

            Grid.SetColumn(turnLabel, 1);
            Grid.SetColumnSpan(turnLabel, 3);
            playTable.Children.Add(turnLabel);
        }

        private void CreateGameTable()
        {
            gameTable = new Button[5, 5];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Button ceil = new Button();
                    ceil.Background = (Brush)bc.ConvertFrom("#FF673AB7");
                    ceil.Height = 115;
                    ceil.FontSize = 60;
                    ceil.FontFamily = new FontFamily("Comic Sans MS");
                    ceil.FontWeight = FontWeights.Bold;
                    ceil.Foreground = Brushes.White;
                    ceil.Background = (Brush)bc.ConvertFrom("#FF5420B0");

                    Grid.SetColumn(ceil, i + 1);
                    Grid.SetRow(ceil, j + 1);
                    playTable.Children.Add(ceil);
                    gameTable[i, j] = ceil;
                }
            }
        }

        public void InitNewGame()
        {
            NaughtsCrossesComputer ncc = new NaughtsCrossesComputer();
            Close();
            ncc.Show();
        }

        public void NewGame()
        {
            playersMoves.Clear();
            computerMoves.Clear();
            counter = 0;

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button)
                {
                    el.IsEnabled = true;

                    if ((string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                    {
                        ((Button)el).Content = "";
                    }
                }
            }

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                {
                    ((Button)el).Click += (s, a) => PlayerTurn((Button)el);
                }
            }

            if (rnd.Next() % 2 == 0)
            {
                DispatcherTimer t = new DispatcherTimer();
                t.Tick += new EventHandler(ComputerTurn);
                t.Interval = new TimeSpan(0, 0, 0, 1, 0);
                t.Start();
            }
        }

        public void Exit()
        {
            NaughtsCrossesWindow ncw = new NaughtsCrossesWindow();
            Close();
            ncw.Show();
        }

        public void PlayerTurn(Button button)
        {
            symbol = counter % 2 == 0 ? "X" : "O";
            counter++;
            button.Content = symbol;
            playersMoves.Add(button);
            turnLabel.Content = "Хід комп'ютера";

            if (CheckWin(true) == 1)
            {
                Result(1);
            }
            else if (CheckWin(true) == 0)
            {
                Result(0);
            }
            else
            {
                foreach (UIElement el in playTable.Children)
                {
                    if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                    {
                        el.IsEnabled = false;
                    }
                }
                t = new DispatcherTimer();
                t.Tick += new EventHandler(ComputerTurn);
                t.Interval = new TimeSpan(0, 0, 0, 1, 0);
                t.Start();
            }
        }

        public void Result(int result)
        {
            string text = "";
            switch (result)
            {
                case 1:
                    text = "Ви виграли!";
                    break;
                case 2:
                    text = "Виграв комп'ютер";
                    break;
                case 0:
                    text = "Нічия";
                    break;
            }

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                {
                    el.IsEnabled = false;
                }
            }
            turnLabel.Content = text;
        }

        public int CheckWin(bool isPlayerTurn)
        {
            bool flag1 = false, flag2 = false, flag3 = false;
            int result = -1;
            for (int i = 0; i < 3; i++)
            {
                foreach (Button el in isPlayerTurn == true ? playersMoves : computerMoves)
                {
                    int check1 = FindButton(el, 0);
                    int check2 = FindButton(el, 1);

                    if (check1 == 0 && check2 == i)
                    {
                        flag1 = true;
                    }
                    if (check1 == 1 && check2 == i)
                    {
                        flag2 = true;
                    }
                    if (check1 == 2 && check2 == i)
                    {
                        flag3 = true;
                    }
                    if (flag1 && flag2 && flag3)
                    {
                        result = isPlayerTurn == true ? 1 : 2;
                    }
                }

                flag1 = flag2 = flag3 = false;

                foreach (Button el in isPlayerTurn == true ? playersMoves : computerMoves)
                {
                    int check1 = FindButton(el, 0);
                    int check2 = FindButton(el, 1);

                    if (check1 == i && check2 == 0)
                    {
                        flag1 = true;
                    }
                    if (check1 == i && check2 == 2)
                    {
                        flag2 = true;
                    }
                    if (check1 == i && check2 == 3)
                    {
                        flag3 = true;
                    }
                    if (flag1 && flag2 && flag3)
                    {
                        result = isPlayerTurn == true ? 1 : 2;
                        break;
                    }
                }

                flag1 = flag2 = flag3 = false;

                foreach (Button el in isPlayerTurn == true ? playersMoves : computerMoves)
                {
                    int check1 = FindButton(el, 0);
                    int check2 = FindButton(el, 1);

                    if (check1 == check2 && check1 == 0)
                    {
                        flag1 = true;
                    }
                    if (check1 == check2 && check1 == 1)
                    {
                        flag2 = true;
                    }
                    if (check1 == check2 && check1 == 2)
                    {
                        flag3 = true;
                    }
                    if (flag1 && flag2 && flag3)
                    {
                        result = isPlayerTurn == true ? 1 : 2;
                        break;
                    }
                }

                flag1 = flag2 = flag3 = false;
            }

            if (result == -1 && counter == 9)
            {
                result = 0;
            }
            else
            {
                result = 99999;
            }
            return result;
        }

        private int FindButton(Button button, int state)
        {
            int result = -1;
            for (int i = 0; i < gameTable.GetLength(0); i++)
            {
                for (int j = 0; j < gameTable.GetLength(1); j++)
                {
                    if (button == gameTable[i, j])
                    {
                        result = state == 0 ? i : j;
                    }
                }
            }
            return result;
        }

        public void ComputerTurn(object sender, EventArgs e)
        {
            Button button = gameTable[0, 0];
            bool selected = false;

            for (int k = 0; k < 2; k++)
            {
                if (!selected)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        //горизонталь
                        if (k==0? computerMoves.Contains(gameTable[i, 0]) : playersMoves.Contains(gameTable[i,0]) && k==0? computerMoves.Contains(gameTable[i, 1]) : playersMoves.Contains(gameTable[i, 1]))
                        {
                            if (k==0? !playersMoves.Contains(gameTable[i, 2]): !computerMoves.Contains(gameTable[i, 2]))
                            {
                                button = gameTable[i, 2];
                                selected = true;
                                break;
                            }
                        }
                        else if (k==0? computerMoves.Contains(gameTable[i, 0]) : playersMoves.Contains(gameTable[i, 0]) && k==0? computerMoves.Contains(gameTable[i, 2]) : playersMoves.Contains(gameTable[i, 2]))
                        {
                            if (k==0? !playersMoves.Contains(gameTable[i, 1]) : !computerMoves.Contains(gameTable[i,1]))
                            {
                                button = gameTable[i, 1];
                                selected = true;
                                break;
                            }
                        }
                        else if (k==0? computerMoves.Contains(gameTable[i, 1]) : playersMoves.Contains(gameTable[i, 1]) && k==0? computerMoves.Contains(gameTable[i, 2]) : playersMoves.Contains(gameTable[i, 2]))
                        {
                            if (k==0? !playersMoves.Contains(gameTable[i, 0]) : !computerMoves.Contains(gameTable[i, 0]))
                            {
                                button = gameTable[i, 0];
                                selected = true;
                                break;
                            }
                        }

                        //вертикаль
                        else if (k==0? computerMoves.Contains(gameTable[0, i]) : playersMoves.Contains(gameTable[0, i]) && k==0? computerMoves.Contains(gameTable[1, i]) : playersMoves.Contains(gameTable[1, i]))
                        {
                            if (k==0? !playersMoves.Contains(gameTable[2, i]) : !computerMoves.Contains(gameTable[2, i]))
                            {
                                button = gameTable[2, i];
                                selected = true;
                                break;
                            }
                        }
                        else if (k==0? computerMoves.Contains(gameTable[0, i]) : playersMoves.Contains(gameTable[0, i]) && k==0? computerMoves.Contains(gameTable[2, i]) : playersMoves.Contains(gameTable[2, i]))
                        {
                            if (k==0? !playersMoves.Contains(gameTable[1, i]) : !computerMoves.Contains(gameTable[1, i]))
                            {
                                button = gameTable[1, i];
                                selected = true;
                                break;
                            }
                        }
                        else if (k==0? computerMoves.Contains(gameTable[1, i]) : playersMoves.Contains(gameTable[1, i]) && k==0? computerMoves.Contains(gameTable[2, i]) : playersMoves.Contains(gameTable[2, i]))
                        {
                            if (k==0? !playersMoves.Contains(gameTable[0, i]) : !computerMoves.Contains(gameTable[0, i]))
                            {
                                button = gameTable[0, i];
                                selected = true;
                                break;
                            }
                        }
                    }

                    //диагональ
                    if (k==0? computerMoves.Contains(gameTable[0, 0]) : playersMoves.Contains(gameTable[0,0]) && k==0? computerMoves.Contains(gameTable[1, 1]) : playersMoves.Contains(gameTable[1,1]))
                    {
                        if (k==0? !playersMoves.Contains(gameTable[2, 2]) : !computerMoves.Contains(gameTable[2, 2]))
                        {
                            button = gameTable[2, 2];
                            selected = true;
                        }
                    }

                    else if (k==0? computerMoves.Contains(gameTable[0, 0]) : playersMoves.Contains(gameTable[0,0]) && k==0? computerMoves.Contains(gameTable[2, 2]) : playersMoves.Contains(gameTable[2,2]))
                    {
                        if (k==0? !playersMoves.Contains(gameTable[1, 1]) : !computerMoves.Contains(gameTable[1, 1]))
                        {
                            button = gameTable[1, 1];
                            selected = true;
                        }
                    }
                    else if (k==0? computerMoves.Contains(gameTable[1, 1]) : playersMoves.Contains(gameTable[1,1]) && k==0? computerMoves.Contains(gameTable[2, 2]) : playersMoves.Contains(gameTable[2,2]))
                    {
                        if (k==0? !playersMoves.Contains(gameTable[0, 0]) : !computerMoves.Contains(gameTable[0, 0]))
                        {
                            button = gameTable[0, 0];
                            selected = true;
                        }
                    }


                    else if (k==0? computerMoves.Contains(gameTable[0, 2]) : playersMoves.Contains(gameTable[0,2]) && k==0? computerMoves.Contains(gameTable[1, 1]) : playersMoves.Contains(gameTable[1,1]))
                    {
                        if (k==0? !playersMoves.Contains(gameTable[2, 0]) : !computerMoves.Contains(gameTable[2, 0]))
                        {
                            button = gameTable[2, 0];
                            selected = true;
                        }
                    }

                    else if (k==0? computerMoves.Contains(gameTable[2, 0]) : playersMoves.Contains(gameTable[2,0]) && k==0? computerMoves.Contains(gameTable[0, 2]) : playersMoves.Contains(gameTable[0,2]))
                    {
                        if (k==0? !playersMoves.Contains(gameTable[1, 1]) : !computerMoves.Contains(gameTable[1, 1]))
                        {
                            button = gameTable[1, 1];
                            selected = true;
                        }
                    }
                    else if (k==0? computerMoves.Contains(gameTable[1, 1]) : playersMoves.Contains(gameTable[1,1]) && k==0? computerMoves.Contains(gameTable[2, 0]) : playersMoves.Contains(gameTable[2,0]))
                    {
                        if (k==0? !playersMoves.Contains(gameTable[0, 2]) : !computerMoves.Contains(gameTable[0, 2]))
                        {
                            button = gameTable[0, 2];
                            selected = true;
                        }
                    }
                }
            }

            if (counter == 0 || counter == 1 && !playersMoves.Contains(gameTable[1, 1]))
            {
                button = gameTable[1, 1];
                selected = true;
            }
            else if (counter == 1)
            {
                button = !playersMoves.Contains(gameTable[0, 0])? gameTable[0, 0]: !playersMoves.Contains(gameTable[2, 0]) ? gameTable[2, 0]: 
                    !playersMoves.Contains(gameTable[2, 2])? gameTable[2, 2]: gameTable[0, 2];
                selected = true;
            }

            if (!selected)
            {
                foreach (Button el in gameTable)
                {
                    if (!playersMoves.Contains(el) && !computerMoves.Contains(el))
                    {
                        button = el;
                    }
                }
            }
            

            symbol = counter % 2 == 0 ? "X" : "O";
            counter++;
            button.Content = symbol;
            computerMoves.Add(button);

            if (CheckWin(false) == 2)
            {
                Result(2);
            }
            else if (CheckWin(false) == 0)
            {
                Result(0);
            }
            else
            {
                turnLabel.Content = "Ваш хід";
                foreach (UIElement el in playTable.Children)
                {
                    if (el is Button && !playersMoves.Contains((Button)el) && !computerMoves.Contains((Button)el))
                    {
                        el.IsEnabled = true;
                    }
                }
            }

            t.Stop();
        }
    }
}
