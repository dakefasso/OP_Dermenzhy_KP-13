﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using Npgsql;

namespace Лабораторная2
{
    /// <summary>
    /// Interaction logic for DataWindow.xaml
    /// </summary>
    public class Student
    {
        public int StudentKey { get; set; }
        public string FullName { get; set; }
        public string Faculty { get; set; }
        public string Group { get; set; }

        public Student(int key, string fullName, string faculty, string group)
        {
            StudentKey = key;
            FullName = fullName;
            Faculty = faculty;
            Group = group;
        }
        public Student() { }
    }
    public partial class DataWindow : Window
    {
        Grid myGrid;
        Button back, addStudentButton, findStudentButton, deleteStudentButton;
        TextBox studentKeyTextBox, facultyTextBox, fullNameTextBox, groupTextBox, findStudentKeyTextBox,
            findFullNameTextBox, resultStudentKeyTextBox, resultFullNameTextBox, resultFacultyTextBox,
             resultGroupTextBox;
        public DataWindow()
        {
            InitializeComponent();
            InitControls();
        }

        private void InitControls()
        {
            myGrid = new Grid();
            RowDefinition[] rows = new RowDefinition[8];
            ColumnDefinition[] cols = new ColumnDefinition[2];

            for (int i = 0; i < 8; i++)
            {
                rows[i] = new RowDefinition();
                myGrid.RowDefinitions.Add(rows[i]);
            }
            for (int i = 0; i < 2; i++)
            {
                cols[i] = new ColumnDefinition();
                myGrid.ColumnDefinitions.Add(cols[i]);
            }

            CreateWindowLabel();

            CreateBackButton();
            CreateAddStudentButton();
            CreateFindStudentButton();
            CreateDeleteStudentButton();

            CreateStudentKeyTextBox();
            CreateFacultyTextBox();
            CreateFullNameTextBox();
            CreateGroupTextBox();

            CreateFindStudentKeyTextBox();
            CreateFindFullNameTextBox();

            CreateResultStudentKeyTextBox();
            CreateResultFullNameTextBox();
            CreateResultFacultyTextBox();
            CreateResultGroupTextBox();

            Content = myGrid;
            Show();
        }

        private void CreateWindowLabel()
        {
            Label windowLabel = new Label();
            windowLabel.HorizontalAlignment = HorizontalAlignment.Center;
            windowLabel.VerticalAlignment = VerticalAlignment.Center;
            windowLabel.Content = "Студентська база";
            windowLabel.FontSize = 30;
            windowLabel.FontFamily = new FontFamily("Comic Sans MS");
            windowLabel.FontWeight = FontWeights.Bold;

            Grid.SetRow(windowLabel, 0);
            Grid.SetColumnSpan(windowLabel, 2);
            myGrid.Children.Add(windowLabel);
        }

        private void CreateBackButton()
        {
            back = new Button();
            back.Content = "Назад";
            back.HorizontalAlignment = HorizontalAlignment.Left;
            back.VerticalAlignment = VerticalAlignment.Top;
            back.Height = 42;
            back.Padding = new Thickness(8, 8, 8, 8);
            back.Margin = new Thickness(7, 7, 7, 7);
            back.FontSize = 20;
            back.FontFamily = new FontFamily("Comic Sans MS");
            back.FontWeight = FontWeights.Bold;

            Grid.SetRow(back, 0);
            Grid.SetColumnSpan(back, 2);
            myGrid.Children.Add(back);

            back.Click += (s, a) => Back();
        }

        private void CreateAddStudentButton()
        {
            addStudentButton = new Button();
            addStudentButton.Content = "Додати нового студента";
            addStudentButton.HorizontalAlignment = HorizontalAlignment.Center;
            addStudentButton.VerticalAlignment = VerticalAlignment.Center;
            addStudentButton.Height = 40;
            addStudentButton.FontSize = 16;
            addStudentButton.FontFamily = new FontFamily("Comic Sans MS");
            addStudentButton.FontWeight = FontWeights.Bold;
            addStudentButton.IsEnabled = false;

            Grid.SetRow(addStudentButton, 3);
            Grid.SetColumnSpan(addStudentButton, 2);
            myGrid.Children.Add(addStudentButton);

            addStudentButton.Click += (s, a) => AddStudent();
        }

        private void CreateFindStudentButton()
        {
            findStudentButton = new Button();
            findStudentButton.Content = "Знайти студента";
            findStudentButton.HorizontalAlignment = HorizontalAlignment.Center;
            findStudentButton.VerticalAlignment = VerticalAlignment.Center;
            findStudentButton.Width = 210;
            findStudentButton.Height = 40;
            findStudentButton.FontSize = 16;
            findStudentButton.FontFamily = new FontFamily("Comic Sans MS");
            findStudentButton.FontWeight = FontWeights.Bold;
            findStudentButton.IsEnabled = false;

            Grid.SetRow(findStudentButton, 5);
            Grid.SetColumn(findStudentButton, 0);
            myGrid.Children.Add(findStudentButton);

            findStudentButton.Click += (s, a) => FindStudent();
        }

        private void CreateDeleteStudentButton()
        {
            deleteStudentButton = new Button();
            deleteStudentButton.Content = "Видалити студента";
            deleteStudentButton.HorizontalAlignment = HorizontalAlignment.Center;
            deleteStudentButton.VerticalAlignment = VerticalAlignment.Center;
            deleteStudentButton.Height = 40;
            deleteStudentButton.Width = 210;
            deleteStudentButton.FontSize = 16;
            deleteStudentButton.FontFamily = new FontFamily("Comic Sans MS");
            deleteStudentButton.FontWeight = FontWeights.Bold;
            deleteStudentButton.IsEnabled = false;

            Grid.SetRow(deleteStudentButton, 5);
            Grid.SetColumn(deleteStudentButton, 1);
            myGrid.Children.Add(deleteStudentButton);

            deleteStudentButton.Click += (s, a) => DeleteStudent();
        }

        private void CreateStudentKeyTextBox()
        {
            studentKeyTextBox = new TextBox();
            studentKeyTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            studentKeyTextBox.VerticalAlignment = VerticalAlignment.Center;
            studentKeyTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(studentKeyTextBox, "Код залікової книжки");
            studentKeyTextBox.FontSize = 18;
            studentKeyTextBox.FontFamily = new FontFamily("Comic Sans MS");
            studentKeyTextBox.FontWeight = FontWeights.Bold;

            Grid.SetRow(studentKeyTextBox, 1);
            Grid.SetColumn(studentKeyTextBox, 0);
            myGrid.Children.Add(studentKeyTextBox);

            studentKeyTextBox.TextChanged += (s, a) => CheckAdd();
        }

        private void CreateFacultyTextBox()
        {
            facultyTextBox = new TextBox();
            facultyTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            facultyTextBox.VerticalAlignment = VerticalAlignment.Center;
            facultyTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(facultyTextBox, "Факультет");
            facultyTextBox.FontSize = 18;
            facultyTextBox.FontFamily = new FontFamily("Comic Sans MS");
            facultyTextBox.FontWeight = FontWeights.Bold;

            Grid.SetRow(facultyTextBox, 2);
            Grid.SetColumn(facultyTextBox, 0);
            myGrid.Children.Add(facultyTextBox);

            facultyTextBox.TextChanged += (s, a) => CheckAdd();
        }

        private void CreateFullNameTextBox()
        {
            fullNameTextBox = new TextBox();
            fullNameTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            fullNameTextBox.VerticalAlignment = VerticalAlignment.Center;
            fullNameTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(fullNameTextBox, "ПІБ");
            fullNameTextBox.FontSize = 18;
            fullNameTextBox.FontFamily = new FontFamily("Comic Sans MS");
            fullNameTextBox.FontWeight = FontWeights.Bold;

            Grid.SetRow(fullNameTextBox, 1);
            Grid.SetColumn(fullNameTextBox, 1);
            myGrid.Children.Add(fullNameTextBox);

            fullNameTextBox.TextChanged += (s, a) => CheckAdd();
        }

        private void CreateGroupTextBox()
        {
            groupTextBox = new TextBox();
            groupTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            groupTextBox.VerticalAlignment = VerticalAlignment.Center;
            groupTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(groupTextBox, "Група");
            groupTextBox.FontSize = 18;
            groupTextBox.FontFamily = new FontFamily("Comic Sans MS");
            groupTextBox.FontWeight = FontWeights.Bold;

            Grid.SetRow(groupTextBox, 2);
            Grid.SetColumn(groupTextBox, 1);
            myGrid.Children.Add(groupTextBox);

            groupTextBox.TextChanged += (s, a) => CheckAdd();
        }

        private void CreateFindStudentKeyTextBox()
        {
            findStudentKeyTextBox = new TextBox();
            findStudentKeyTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            findStudentKeyTextBox.VerticalAlignment = VerticalAlignment.Center;
            findStudentKeyTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(findStudentKeyTextBox, "Код залікової книжки");
            findStudentKeyTextBox.FontSize = 18;
            findStudentKeyTextBox.FontFamily = new FontFamily("Comic Sans MS");
            findStudentKeyTextBox.FontWeight = FontWeights.Bold;

            Grid.SetRow(findStudentKeyTextBox, 4);
            Grid.SetColumn(findStudentKeyTextBox, 0);
            myGrid.Children.Add(findStudentKeyTextBox);

            findStudentKeyTextBox.TextChanged += (s, a) => CheckFind();
        }

        private void CreateFindFullNameTextBox()
        {
            findFullNameTextBox = new TextBox();
            findFullNameTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            findFullNameTextBox.VerticalAlignment = VerticalAlignment.Center;
            findFullNameTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(findFullNameTextBox, "ПІБ");
            findFullNameTextBox.FontSize = 18;
            findFullNameTextBox.FontFamily = new FontFamily("Comic Sans MS");
            findFullNameTextBox.FontWeight = FontWeights.Bold;

            Grid.SetRow(findFullNameTextBox, 4);
            Grid.SetColumn(findFullNameTextBox, 1);
            myGrid.Children.Add(findFullNameTextBox);

            findFullNameTextBox.TextChanged += (s, a) => CheckFind();
        }



        private void CreateResultStudentKeyTextBox()
        {
            resultStudentKeyTextBox = new TextBox();
            resultStudentKeyTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            resultStudentKeyTextBox.VerticalAlignment = VerticalAlignment.Center;
            resultStudentKeyTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(resultStudentKeyTextBox, "                        ");
            resultStudentKeyTextBox.FontSize = 18;
            resultStudentKeyTextBox.FontFamily = new FontFamily("Comic Sans MS");
            resultStudentKeyTextBox.FontWeight = FontWeights.Bold;
            resultStudentKeyTextBox.IsEnabled = false;

            Grid.SetRow(resultStudentKeyTextBox, 6);
            Grid.SetColumn(resultStudentKeyTextBox, 0);
            myGrid.Children.Add(resultStudentKeyTextBox);
        }

        private void CreateResultFullNameTextBox()
        {
            resultFullNameTextBox = new TextBox();
            resultFullNameTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            resultFullNameTextBox.VerticalAlignment = VerticalAlignment.Center;
            resultFullNameTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(resultFullNameTextBox, "                        ");
            resultFullNameTextBox.FontSize = 18;
            resultFullNameTextBox.FontFamily = new FontFamily("Comic Sans MS");
            resultFullNameTextBox.FontWeight = FontWeights.Bold;
            resultFullNameTextBox.IsEnabled = false;

            Grid.SetRow(resultFullNameTextBox, 6);
            Grid.SetColumn(resultFullNameTextBox, 1);
            myGrid.Children.Add(resultFullNameTextBox);
        }

        private void CreateResultFacultyTextBox()
        {
            resultFacultyTextBox = new TextBox();
            resultFacultyTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            resultFacultyTextBox.VerticalAlignment = VerticalAlignment.Center;
            resultFacultyTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(resultFacultyTextBox, "                        ");
            resultFacultyTextBox.FontSize = 18;
            resultFacultyTextBox.FontFamily = new FontFamily("Comic Sans MS");
            resultFacultyTextBox.FontWeight = FontWeights.Bold;
            resultFacultyTextBox.IsEnabled = false;

            Grid.SetRow(resultFacultyTextBox, 7);
            Grid.SetColumn(resultFacultyTextBox, 0);
            myGrid.Children.Add(resultFacultyTextBox);
        }

        private void CreateResultGroupTextBox()
        {
            resultGroupTextBox = new TextBox();
            resultGroupTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            resultGroupTextBox.VerticalAlignment = VerticalAlignment.Center;
            resultGroupTextBox.Margin = new Thickness(24, 10, 10, 10);
            MaterialDesignThemes.Wpf.HintAssist.SetHint(resultGroupTextBox, "                        ");
            resultGroupTextBox.FontSize = 18;
            resultGroupTextBox.FontFamily = new FontFamily("Comic Sans MS");
            resultGroupTextBox.FontWeight = FontWeights.Bold;
            resultGroupTextBox.IsEnabled = false;

            Grid.SetRow(resultGroupTextBox, 7);
            Grid.SetColumn(resultGroupTextBox, 1);
            myGrid.Children.Add(resultGroupTextBox);
        }

        private void CheckAdd()
        {
            try
            {
                addStudentButton.IsEnabled = facultyTextBox.Text == "" || studentKeyTextBox.Text.Length != 6 ||
                studentKeyTextBox.Text == "" || fullNameTextBox.Text == "" || groupTextBox.Text == "" ||
                fullNameTextBox.Text.Split(' ').Length != 3 ||
                fullNameTextBox.Text.Substring(fullNameTextBox.Text.Length - 1, 1) == " " ? false : true;
            }
            catch { addStudentButton.IsEnabled = false; }

        }

        private void CheckFind()
        {
            findStudentButton.IsEnabled = findFullNameTextBox.Text != "" &&
             findFullNameTextBox.Text.Split(' ').Length == 3 || findStudentKeyTextBox.Text.Length == 6 ? true : false;
        }

        private void Back()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }

        private void AddStudent()
        {
            Student student = new Student(int.Parse(studentKeyTextBox.Text), fullNameTextBox.Text,
                facultyTextBox.Text, groupTextBox.Text);

            NpgsqlConnection connection = new NpgsqlConnection($@"Server=localhost;Port=5432;User Id=postgres;Password=25614;Database=Laba1");
            connection.Open();
            NpgsqlCommand command = connection.CreateCommand();

            command.CommandText = @$"INSERT INTO students (student_key, full_name, faculty, student_group) 
                              VALUES (@key, @name, @faculty, @group)";
            command.Parameters.AddWithValue("name", student.FullName);
            command.Parameters.AddWithValue("key", student.StudentKey);
            command.Parameters.AddWithValue("faculty", student.Faculty);
            command.Parameters.AddWithValue("group", student.Group);

            fullNameTextBox.Text = null;
            studentKeyTextBox.Text = null;
            facultyTextBox.Text = null;
            groupTextBox.Text = null;

            command.ExecuteScalar();
            connection.Close();
        }

        private Student FindStudent()
        {
            int studentKey = int.Parse(findStudentKeyTextBox.Text);
            string fullName = findFullNameTextBox.Text;

            NpgsqlConnection connection = new NpgsqlConnection($@"Server=localhost;Port=5432;User Id=postgres;Password=25614;Database=Laba1");
            connection.Open();
            NpgsqlCommand command = connection.CreateCommand();

            command.CommandText = @$"SELECT * FROM students WHERE student_key = @key OR full_name = @fullName";
            command.Parameters.AddWithValue("key", studentKey);
            command.Parameters.AddWithValue("fullName", fullName);

            NpgsqlDataReader reader = command.ExecuteReader();
            Student student = new Student();
            if (reader.Read())
            {
                student = GetStudent(reader);
                ShowStudentData(student);
                deleteStudentButton.IsEnabled = true;
            }
            else
            {
                StudentNotFound();
            }

            return student;

            reader.Close();
            connection.Close();
        }

        private Student GetStudent(NpgsqlDataReader reader)
        {
            Student student = new Student();
            student.StudentKey = reader.GetInt32(0);
            student.FullName = reader.GetString(1);
            student.Faculty = reader.GetString(2);
            student.Group = reader.GetString(3);

            return student;
        }

        private void ShowStudentData(Student student)
        {
            resultStudentKeyTextBox.Text = student.StudentKey.ToString();
            resultFacultyTextBox.Text = student.Faculty;
            resultGroupTextBox.Text = student.Group;
            resultFullNameTextBox.Text = student.FullName;
        }

        private void StudentNotFound()
        {
            resultStudentKeyTextBox.Text = "Не знайдено";
            resultFacultyTextBox.Text = "Не знайдено";
            resultGroupTextBox.Text = "Не знайдено";
            resultFullNameTextBox.Text = "Не знайдено";
        }

        private void DeleteStudent()
        {
            Student student = FindStudent();

            NpgsqlConnection connection = new NpgsqlConnection($@"Server=localhost;Port=5432;User Id=postgres;Password=25614;Database=Laba1");
            connection.Open();
            NpgsqlCommand command = connection.CreateCommand();

            command.CommandText = @$"DELETE FROM students * WHERE full_name = @name OR student_key = @key";
            command.Parameters.AddWithValue("name", student.FullName);
            command.Parameters.AddWithValue("key", student.StudentKey);

            command.ExecuteScalar();
            connection.Close();

            resultStudentKeyTextBox.Text = "Видалено";
            resultFacultyTextBox.Text = "Видалено";
            resultGroupTextBox.Text = "Видалено";
            resultFullNameTextBox.Text = "Видалено";

            deleteStudentButton.IsEnabled = false;
        }
    }
}

