﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Лабораторная2
{
    /// <summary>
    /// Interaction logic for AuthorWindow.xaml
    /// </summary>
    public partial class AuthorWindow : Window
    {
        static int M = 3, N = 2;
        public AuthorWindow()
        {
            InitializeComponent();
            InitControls();
        }

        private void InitControls()
        {
            Title = "Про автора";
            ResizeMode = ResizeMode.NoResize;

            Grid myGrid = new Grid();

            RowDefinition[] rows = new RowDefinition[M];
            ColumnDefinition[] cols = new ColumnDefinition[N];

            for (int i = 0; i < M; i++)
            {
                rows[i] = new RowDefinition();
                myGrid.RowDefinitions.Add(rows[i]);
            }
            for (int i = 0; i < N; i++)
            {
                cols[i] = new ColumnDefinition();
                myGrid.ColumnDefinitions.Add(cols[i]);
            }

            Label windowTitle = new Label();
            windowTitle.HorizontalAlignment = HorizontalAlignment.Center;
            windowTitle.VerticalAlignment = VerticalAlignment.Center;
            windowTitle.FontSize = 30;
            windowTitle.FontFamily = new FontFamily("Comic Sans MS");
            windowTitle.FontWeight = FontWeights.Bold;
            windowTitle.Content = "Автор проєкту";

            Grid.SetRow(windowTitle, 0);
            Grid.SetColumnSpan(windowTitle, 2);
            myGrid.Children.Add(windowTitle);


            Label PIB = new Label();
            PIB.HorizontalAlignment = HorizontalAlignment.Center;
            PIB.VerticalAlignment = VerticalAlignment.Top;
            PIB.Margin = new Thickness(10, 10, 10, 10);
            PIB.FontSize = 22;
            PIB.FontFamily = new FontFamily("Comic Sans MS");
            PIB.FontWeight = FontWeights.Bold;
            PIB.Content = "ПІБ";

            Grid.SetRow(PIB, 1);
            Grid.SetColumnSpan(PIB, 2);
            myGrid.Children.Add(PIB);


            Label fullName = new Label();
            fullName.HorizontalAlignment = HorizontalAlignment.Center;
            fullName.VerticalAlignment = VerticalAlignment.Bottom;
            fullName.Margin = new Thickness(10, 10, 10, 10);
            fullName.FontSize = 22;
            fullName.FontFamily = new FontFamily("Comic Sans MS");
            fullName.FontWeight = FontWeights.Bold;
            fullName.Content = "Дерменжи Ілля Сергійович";

            Grid.SetRow(fullName, 1);
            Grid.SetColumnSpan(fullName, 2);
            myGrid.Children.Add(fullName);


            Label groupTitle = new Label();
            groupTitle.HorizontalAlignment = HorizontalAlignment.Left;
            groupTitle.VerticalAlignment = VerticalAlignment.Top;
            groupTitle.Margin = new Thickness(8, 8, 8, 8);
            groupTitle.FontSize = 22;
            groupTitle.FontFamily = new FontFamily("Comic Sans MS");
            groupTitle.FontWeight = FontWeights.Bold;
            groupTitle.Content = "Група";

            Grid.SetRow(groupTitle, 2);
            Grid.SetColumn(groupTitle, 0);
            myGrid.Children.Add(groupTitle);


            Label group = new Label();
            group.HorizontalAlignment = HorizontalAlignment.Left;
            group.VerticalAlignment = VerticalAlignment.Bottom;
            group.Margin = new Thickness(8, 8, 8, 8);
            group.FontSize = 22;
            group.FontFamily = new FontFamily("Comic Sans MS");
            group.FontWeight = FontWeights.Bold;
            group.Content = "КП-13";

            Grid.SetRow(group, 2);
            Grid.SetColumn(group, 0);
            myGrid.Children.Add(group);


            Label dateTitle = new Label();
            dateTitle.HorizontalAlignment = HorizontalAlignment.Right;
            dateTitle.VerticalAlignment = VerticalAlignment.Top;
            dateTitle.Margin = new Thickness(8, 8, 8, 8);
            dateTitle.FontSize = 22;
            dateTitle.FontFamily = new FontFamily("Comic Sans MS");
            dateTitle.FontWeight = FontWeights.Bold;
            dateTitle.Content = "Дата створення";

            Grid.SetRow(dateTitle, 2);
            Grid.SetColumn(dateTitle, 1);
            myGrid.Children.Add(dateTitle);


            Label date = new Label();
            date.HorizontalAlignment = HorizontalAlignment.Right;
            date.VerticalAlignment = VerticalAlignment.Bottom;
            date.Margin = new Thickness(8, 8, 8, 8);
            date.FontSize = 22;
            date.FontFamily = new FontFamily("Comic Sans MS");
            date.FontWeight = FontWeights.Bold;
            date.Content = "24.02.2022";

            Grid.SetRow(date, 2);
            Grid.SetColumn(date, 1);
            myGrid.Children.Add(date);


            Button back = new Button();
            back.Content = "Назад";
            back.HorizontalAlignment = HorizontalAlignment.Left;
            back.VerticalAlignment = VerticalAlignment.Top;
            back.Height = 42;
            back.Padding = new Thickness(8, 8, 8, 8);
            back.Margin = new Thickness(7, 7, 7, 7);
            back.FontSize = 20;
            back.FontFamily = new FontFamily("Comic Sans MS");
            back.FontWeight = FontWeights.Bold;

            back.Click += (s, a) => Back();

            Grid.SetRow(back, 0);
            Grid.SetColumn(back, 0);
            myGrid.Children.Add(back);


            Content = myGrid;
            Show();
        }

        private void Back()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }
    }
}

