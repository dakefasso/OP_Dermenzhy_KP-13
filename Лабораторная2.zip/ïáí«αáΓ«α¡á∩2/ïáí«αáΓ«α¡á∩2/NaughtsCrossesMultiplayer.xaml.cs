﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;

namespace Лабораторная2
{
    /// <summary>
    /// Interaction logic for NaughtsCrossesMultiplayer.xaml
    /// </summary>
    public partial class NaughtsCrossesMultiplayer : Window
    {
        int counter;
        List<Button> firstPlayerMoves = new List<Button>();
        List<Button> secondPlayerMoves = new List<Button>();
        Grid playTable;
        Label turnLabel;
        BrushConverter bc = new BrushConverter();
        Button[,] gameTable;
        public NaughtsCrossesMultiplayer()
        {
            InitializeComponent();
            InitControls();
            NewGame();
        }

        private void InitControls()
        {
            playTable = new Grid();
            playTable.Background = (Brush)bc.ConvertFrom("#FF673AB7");
            playTable.Margin = new Thickness(10, 10, 10, 10);
            RowDefinition[] rows = new RowDefinition[7];
            ColumnDefinition[] cols = new ColumnDefinition[7];

            for (int i = 0; i < 7; i++)
            {
                rows[i] = new RowDefinition();
                if (i == 6)
                {
                    rows[i].Height = new GridLength(100);
                }
                playTable.RowDefinitions.Add(rows[i]);
            }
            for (int i = 0; i < 7; i++)
            {
                cols[i] = new ColumnDefinition();
                if (i > 0 && i < 6)
                {
                    cols[i].Width = new GridLength(115);
                }
                playTable.ColumnDefinitions.Add(cols[i]);
            }

            CreateExitButton();
            CreateTurnLabel();
            CreateNewGameButton();
            CreateGameTable();

            Content = playTable;
            Show();
        }

        private void CreateNewGameButton()
        {
            Button newGame = new Button();
            newGame.Content = "Нова гра";
            newGame.HorizontalAlignment = HorizontalAlignment.Center;
            newGame.VerticalAlignment = VerticalAlignment.Top;
            newGame.HorizontalContentAlignment = HorizontalAlignment.Center;
            newGame.Height = 50;
            newGame.Width = 200;
            newGame.Margin = new Thickness(15, 15, 15, 15);
            newGame.FontSize = 30;
            newGame.FontFamily = new FontFamily("Comic Sans MS");
            newGame.FontWeight = FontWeights.Bold;
            newGame.Background = (Brush)bc.ConvertFrom("#FF300A74");
            newGame.Foreground = Brushes.White;

            Grid.SetColumn(newGame, 2);
            Grid.SetColumnSpan(newGame, 3);
            Grid.SetRow(newGame, 6);
            playTable.Children.Add(newGame);

            newGame.Click += (s, a) => InitNewGame();
        }

        private void CreateTurnLabel()
        {
            turnLabel = new Label();
            turnLabel.Content = "Ваш хід";
            turnLabel.HorizontalAlignment = HorizontalAlignment.Center;
            turnLabel.VerticalAlignment = VerticalAlignment.Center;
            turnLabel.Margin = new Thickness(5, 5, 5, 5);
            turnLabel.FontSize = 28;
            turnLabel.FontFamily = new FontFamily("Comic Sans MS");
            turnLabel.FontWeight = FontWeights.Bold;
            turnLabel.Foreground = Brushes.White;

            Grid.SetColumn(turnLabel, 2);
            Grid.SetColumnSpan(turnLabel, 3);
            playTable.Children.Add(turnLabel);
        }

        private void CreateExitButton()
        {
            Button back = new Button();
            back.Content = "";
            back.HorizontalAlignment = HorizontalAlignment.Left;
            back.VerticalAlignment = VerticalAlignment.Top;
            back.HorizontalContentAlignment = HorizontalAlignment.Center;
            back.Height = 50;
            back.Width = 100;
            back.Margin = new Thickness(5, 5, 5, 5);
            back.Content = "Назад";
            back.FontSize = 24;
            back.FontFamily = new FontFamily("Comic Sans MS");
            back.FontWeight = FontWeights.Bold;
            back.Background = (Brush)bc.ConvertFrom("#FF5420B0");

            Grid.SetColumnSpan(back, 2);
            playTable.Children.Add(back);

            back.Click += (s, a) => Exit();
        }

        private void CreateGameTable()
        {
            gameTable = new Button[5, 5];
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Button ceil = new Button();
                    ceil.Background = (Brush)bc.ConvertFrom("#FF673AB7");
                    ceil.Height = 115;
                    ceil.FontSize = 60;
                    ceil.FontFamily = new FontFamily("Comic Sans MS");
                    ceil.FontWeight = FontWeights.Bold;
                    ceil.Foreground = Brushes.White;
                    ceil.Background = (Brush)bc.ConvertFrom("#FF5420B0");

                    Grid.SetColumn(ceil, i + 1);
                    Grid.SetRow(ceil, j + 1);
                    playTable.Children.Add(ceil);
                    gameTable[i,j] = ceil;
                }
            }
        }

        private void InitNewGame()
        {
            NaughtsCrossesMultiplayer ncm = new NaughtsCrossesMultiplayer();
            Close();
            ncm.Show();
        }

        private void NewGame()
        {
            turnLabel.Content = "Хід першого гравця";
            counter = 0;
            firstPlayerMoves.Clear();
            secondPlayerMoves.Clear();

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button)
                {
                    el.IsEnabled = true;
                }
            }

            foreach (UIElement el in playTable.Children)
            {
                if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                {
                    ((Button)el).Click += (s, a) => NextTurn((Button)el);
                }
            }
        }
        private void NextTurn(Button button)
        {
            string symbol;

            if (counter % 2 == 0)
            {
                symbol = "X";
                firstPlayerMoves.Add(button);
                turnLabel.Content = "Хід другого гравця";
            }
            else
            {
                symbol = "O";
                secondPlayerMoves.Add(button);
                turnLabel.Content = "Хід першого гравця";
            }

            button.Content = symbol;
            counter++;

            DisableButtons(1);
            CheckResult();
        }

        private void CheckResult()
        {
            if (CheckWin(1) == true)
            {
                DisableButtons(0);
                turnLabel.Content = "Гравець 1 виграв!";
            }
            else if (CheckWin(2) == true)
            {
                DisableButtons(0);
                turnLabel.Content = "Гравець 2 виврав!";
            }
            else if (counter == 25)
            {
                DisableButtons(0);
                turnLabel.Content = "Нічия!";
            }
        }

        private string FindButton(Button button, int state)
        {
            string result = "";
            for (int i = 0; i < gameTable.GetLength(0); i++)
            {
                for (int j = 0; j < gameTable.GetLength(1); j++)
                {
                    if (button == gameTable[i, j])
                    {
                        result = state == 0 ? Convert.ToString(i) : Convert.ToString(j);
                    }
                }
            }
            return result;
        }

        private bool CheckWin(int player)
        {
            bool flag1 = false, flag2 = false, flag3 = false, flag4 = false, mainflag = false;

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    //проверка по горизонтали 
                    foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                    {
                        string check1 = FindButton(el, 0);
                        string check2 = FindButton(el, 1);

                        if (check1 == Convert.ToString(j) && check2 == Convert.ToString(i))
                        {
                            flag1 = true;
                        }
                        if (check1 == Convert.ToString(j + 1) && check2 == Convert.ToString(i))
                        {
                            flag2 = true;
                        }
                        if (check1 == Convert.ToString(j + 2) && check2 == Convert.ToString(i))
                        {
                            flag3 = true;
                        }
                        if (check1 == Convert.ToString(j + 3) && check2 == Convert.ToString(i))
                        {
                            flag4 = true;
                        }
                        if (flag1 && flag2 && flag3 && flag4)
                        {
                            mainflag = true;
                        }
                    }

                    flag1 = flag2 = flag3 = flag4 = false;

                    //проверка по вертикали
                    foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                    {
                        string check1 = FindButton(el, 0);
                        string check2 = FindButton(el, 1);

                        if (check1 == Convert.ToString(i) && check2 == Convert.ToString(j))
                        {
                            flag1 = true;
                        }
                        if (check1 == Convert.ToString(i) && check2 == Convert.ToString(j + 1))
                        {
                            flag2 = true;
                        }
                        if (check1 == Convert.ToString(i) && check2 == Convert.ToString(j + 2))
                        {
                            flag3 = true;
                        }
                        if (check1 == Convert.ToString(i) && check2 == Convert.ToString(j + 3))
                        {
                            flag4 = true;
                        }
                        if (flag1 && flag2 && flag3 && flag4)
                        {
                            mainflag = true;
                        }
                    }
                    flag1 = flag2 = flag3 = flag4 = false;
                }
            }

            //проверка по диагонали
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    if (j % 2 == 0)
                    {
                        foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                        {
                            string check1 = FindButton(el, 0);
                            string check2 = FindButton(el, 1);

                            if (check1 == Convert.ToString(1 + i) && check2 == Convert.ToString(1 + i))
                            {
                                flag1 = true;
                            }
                            if (check1 == Convert.ToString(2 + i) && check2 == Convert.ToString(2 + i))
                            {
                                flag2 = true;
                            }
                            if (check1 == Convert.ToString(3 + i) && check2 == Convert.ToString(3 + i))
                            {
                                flag3 = true;
                            }
                            if (check1 == Convert.ToString(4 + i) && check2 == Convert.ToString(4 + i))
                            {
                                flag4 = true;
                            }
                            if (flag1 && flag2 && flag3 && flag4)
                            {
                                mainflag = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                        {
                            string check1 = FindButton(el, 0);
                            string check2 = FindButton(el, 1);

                            if (check1 == Convert.ToString(1 + i) && check2 == Convert.ToString(5 - i))
                            {
                                flag1 = true;
                            }
                            if (check1 == Convert.ToString(2 + i) && check2 == Convert.ToString(4 - i))
                            {
                                flag2 = true;
                            }
                            if (check1 == Convert.ToString(3 + i) && check2 == Convert.ToString(3 - i))
                            {
                                flag3 = true;
                            }
                            if (check1 == Convert.ToString(4 + i) && check2 == Convert.ToString(2 - i))
                            {
                                flag4 = true;
                            }
                            if (flag1 && flag2 && flag3 && flag4)
                            {
                                mainflag = true;
                            }
                        }
                    }

                    flag1 = flag2 = flag3 = flag4 = false;
                }
            }

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    if (j % 2 == 0)
                    {
                        foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                        {
                            string check1 = FindButton(el, 0);
                            string check2 = FindButton(el, 1);

                            if (check1 == Convert.ToString(2 - i) && check2 == Convert.ToString(1 + i))
                            {
                                flag1 = true;
                            }
                            if (check1 == Convert.ToString(3 - i) && check2 == Convert.ToString(2 + i))
                            {
                                flag2 = true;
                            }
                            if (check1 == Convert.ToString(4 - i) && check2 == Convert.ToString(3 + i))
                            {
                                flag3 = true;
                            }
                            if (check1 == Convert.ToString(5 - i) && check2 == Convert.ToString(4 + i))
                            {
                                flag4 = true;
                            }
                            if (flag1 && flag2 && flag3 && flag4)
                            {
                                mainflag = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (Button el in player == 1 ? firstPlayerMoves : secondPlayerMoves)
                        {
                            string check1 = FindButton(el, 0);
                            string check2 = FindButton(el, 1);

                            if (check1 == Convert.ToString(1 + i) && check2 == Convert.ToString(4 + i))
                            {
                                flag1 = true;
                            }
                            if (check1 == Convert.ToString(2 + i) && check2 == Convert.ToString(3 + i))
                            {
                                flag2 = true;
                            }
                            if (check1 == Convert.ToString(3 + i) && check2 == Convert.ToString(2 + i))
                            {
                                flag3 = true;
                            }
                            if (check1 == Convert.ToString(4 + i) && check2 == Convert.ToString(1 + i))
                            {
                                flag4 = true;
                            }
                            if (flag1 && flag2 && flag3 && flag4)
                            {
                                mainflag = true;
                            }
                        }
                    }

                    flag1 = flag2 = flag3 = flag4 = false;
                }
            }

            if (mainflag == true)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        private void DisableButtons(int state)
        {
            if (state == 0)
            {
                foreach (UIElement el in playTable.Children)
                {
                    if (el is Button && (string)((Button)el).Content != "Назад" && (string)((Button)el).Content != "Нова гра")
                    {
                        el.IsEnabled = false;
                    }
                }
            }
            else
            {
                foreach (Button button in firstPlayerMoves)
                {
                    button.IsEnabled = false;
                }
                foreach (Button button in secondPlayerMoves)
                {
                    button.IsEnabled = false;
                }
            }
        }

        private void Exit()
        {
            NaughtsCrossesWindow ncw = new NaughtsCrossesWindow();
            Close();
            ncw.Show();
        }
    }
}
