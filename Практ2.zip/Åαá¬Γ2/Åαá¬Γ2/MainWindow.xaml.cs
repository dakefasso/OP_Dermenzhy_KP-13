﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using static System.Math;
using System.Windows.Shapes;
using System.Threading.Tasks;
using DataVis = System.Windows.Forms.DataVisualization;

namespace Практ2
{
    public partial class MainWindow : Window
    {
        Random rnd = new Random();
        int[] pointX, pointY;
        Ellipse[] grEllipse, genEllipse;
        string[] wasUsed;
        int lastPoint, generationCount;
        bool flag, flag1;
        double grTotalDistance;
        int[,] population, bestOfPopulation;
        public MainWindow()
        {
            InitializeComponent();
            lastPoint = 0;
            flag = flag1 = true;

            startGreedyButton.IsEnabled = false;
            startGeneticButton.IsEnabled = false;
            stopButton.IsEnabled = false;

            exitButton.Click += (s, a) => Close();
            createFieldButton.Click += (s, a) => CreateField();
            startGreedyButton.Click += (s, a) => StartGreedyInit(lastPoint);
            startGeneticButton.Click += (s, a) => StartGeneticInit();
        }

        private void CreateField()
        {
            try
            {
                DeleteOldField();

                int pointsAmount = int.Parse(pointsAmountTB.Text);

                int time = int.Parse(timeTB.Text);

                pointX = new int[pointsAmount];
                pointY = new int[pointsAmount];
                grEllipse = new Ellipse[pointsAmount];
                genEllipse = new Ellipse[pointsAmount];
                wasUsed = new string[pointsAmount];

                for (int i = 0; i < pointsAmount; i++)
                {
                    pointX[i] = rnd.Next(10, 731);
                    pointY[i] = rnd.Next(10, 411);

                    CreatePoint(i);
                }

                startGreedyButton.IsEnabled = true;
                startGeneticButton.IsEnabled = true;

                graph.Series[0].Points.Clear();
                graph.Series[1].Points.Clear();

                population = CreatePopulation();
            }
            catch
            {
                MessageBox.Show("Можно нормальные значения указать в параметрах?");
            }
        }

        private void DeleteOldField()
        {
            pointX = pointY = null;
            greedyField.Children.Clear();
            geneticField.Children.Clear();
            grTotalDistance = 0;
            grTotalDistanceLabel.Content = 0;
            lastPoint = 0;
        }

        private void CreatePoint(int i)
        {
            Ellipse grPoint = new Ellipse();
            grPoint.Width = 16;
            grPoint.Height = 16;
            grPoint.Fill = new SolidColorBrush(Colors.ForestGreen);
            greedyField.Children.Add(grPoint);
            Canvas.SetLeft(grPoint, pointX[i]);
            Canvas.SetTop(grPoint, pointY[i]);
            grEllipse[i] = grPoint;

            Ellipse genPoint = new Ellipse();
            genPoint.Width = 16;
            genPoint.Height = 16;
            genPoint.Fill = new SolidColorBrush(Colors.ForestGreen);
            geneticField.Children.Add(genPoint);
            Canvas.SetLeft(genPoint, pointX[i]);
            Canvas.SetTop(genPoint, pointY[i]);
            genEllipse[i] = genPoint;
        }

        async private void StartGeneticInit()
        {
            startGreedyButton.IsEnabled = false;
            startGeneticButton.IsEnabled = false;
            stopButton.IsEnabled = true;
            createFieldButton.IsEnabled = false;
            flag1 = true;

            await StartGenetic();    
        }

        async private Task<int> StartGenetic()
        {
            if (flag1)
            {
                generationCount++;
                int populationSize = int.Parse(populationSizeTB.Text);
                bestOfPopulation = FindBest(population);
                population = CreateChildren(bestOfPopulation);

                int[] shortestOfPopulation = await DisplayShortest(population);
                await ConnectGenetic(shortestOfPopulation);

                stopButton.Click += (s, a) => StopGenetic();
                await StartGenetic();         
            }
            return 0;
        }

        private int[,] CreatePopulation() 
        {
            int populationSize = int.Parse(populationSizeTB.Text);
            int pointsAmount = int.Parse(pointsAmountTB.Text);
            int[,] newPopulation = new int[populationSize, pointsAmount];
            bool check1 = false;

            for (int i = 0; i < populationSize; i++)
            {
                for (int j = 0; j < pointsAmount; j++)
                {
                    newPopulation[i, j] = 9999;
                }
            }

            for (int i = 0; i < populationSize; i++)
            {
                for (int j = 0; j < pointsAmount; j++)
                {
                    int number = rnd.Next(0, pointsAmount);

                    while (check1 == false)
                    {
                        check1 = true;
                        for (int k = 0; k < pointsAmount; k++)
                        {
                            if (number == newPopulation[i, k])
                            {
                                check1 = false;
                                number = rnd.Next(0, pointsAmount);
                            }
                        }
                    }
                    check1 = false;
                    newPopulation[i, j] = number;
                }
            }

            return newPopulation;
        }

        private int[,] FindBest(int[,] population) 
        {
            int populationSize = int.Parse(populationSizeTB.Text);
            int pointsAmount = int.Parse(pointsAmountTB.Text);
            int[,] bestOfPopulation = new int[populationSize / 2, pointsAmount];

            for (int i = 0; i < populationSize / 2; i++)
            {
                int position = 9999999;
                double minDistance = 999999999;

                for (int j = 0; j < populationSize; j++)
                {
                    if (population[j, 0] != -1)
                    {
                        double distance = 0;
                        for (int k = 0; k < pointsAmount - 1; k++)
                        {
                            distance += CalculateDistance(population[j, k], population[j, k + 1]);
                        }
                        distance += CalculateDistance(population[j, 0], population[j, pointsAmount - 1]);
                        if (distance < minDistance)
                        {
                            minDistance = distance;
                            position = j;
                        }
                    }
                }

                for (int m = 0; m < pointsAmount; m++)
                {
                    bestOfPopulation[i, m] = population[position, m];
                    population[position, m] = -1;
                }
            }

            return bestOfPopulation;
        }

        private int[,] CreateChildren(int[,] bestOfPopulation)
        {
            int populationSize = int.Parse(populationSizeTB.Text);
            int pointsAmount = int.Parse(pointsAmountTB.Text);
            int[,] population = new int[populationSize, pointsAmount];

            for (int i = 0; i < populationSize / 2; i++)
            {
                int parent_1 = rnd.Next(0, populationSize / 2);
                int parent_2 = rnd.Next(0, populationSize / 2);
                int pointOfDevision = rnd.Next(1, pointsAmount - 1);

                while (parent_1 == parent_2)
                {
                    parent_2 = rnd.Next(0, populationSize / 2);
                }

                int[] child = new int[pointsAmount];

                for (int j = 0; j < pointsAmount; j++)
                {
                    child[j] = 999999;
                }

                int[] temp_11 = new int[pointOfDevision],
                    temp_21 = new int[pointOfDevision],
                    temp_12 = new int[pointsAmount - pointOfDevision],
                    temp_22 = new int[pointsAmount - pointOfDevision];

                for (int j = 0; j < pointOfDevision; j++)
                {
                    temp_11[j] = bestOfPopulation[parent_1, j];
                    temp_21[j] = bestOfPopulation[parent_2, j];
                }

                for (int j = pointOfDevision; j < pointsAmount; j++)
                {
                    temp_12[j - pointOfDevision] = bestOfPopulation[parent_1, j];
                    temp_22[j - pointOfDevision] = bestOfPopulation[parent_2, j];
                }

                if (rnd.Next(1, 3) == 1)
                {
                    for (int k = 0; k < pointOfDevision; k++)
                    {
                        child[k] = temp_11[k];
                    }
                    for (int k = 0; k < pointsAmount - pointOfDevision; k++)
                    {
                        bool flag1 = true;
                        for (int m = 0; m < pointsAmount; m++)
                        {
                            if (temp_22[k] == child[m])
                            {
                                flag1 = false;
                            }
                        }
                        if (flag1)
                        {
                            for (int g = 0; g < pointsAmount; g++)
                            {
                                if (child[g] == 999999)
                                {
                                    child[g] = temp_22[k];
                                    break;
                                }
                            }
                        }
                    }

                    for (int k = 0; k < pointOfDevision; k++)
                    {
                        bool flag1 = true;
                        for (int m = 0; m < pointsAmount; m++)
                        {
                            if (temp_21[k] == child[m])
                            {
                                flag1 = false;
                            }
                        }
                        if (flag1)
                        {
                            for (int g = 0; g < pointsAmount; g++)
                            {
                                if (child[g] == 999999)
                                {
                                    child[g] = temp_21[k];
                                    break;
                                }
                            }
                        }
                    }
                }
                else
                {
                    for (int k = 0; k < pointOfDevision; k++)
                    {
                        child[k] = temp_21[k];
                    }
                    for (int k = 0; k < pointsAmount - pointOfDevision; k++)
                    {
                        bool flag1 = true;
                        for (int m = 0; m < pointsAmount; m++)
                        {
                            if (temp_12[k] == child[m])
                            {
                                flag1 = false;
                            }
                        }
                        if (flag1)
                        {
                            for (int g = 0; g < pointsAmount; g++)
                            {
                                if (child[g] == 999999)
                                {
                                    child[g] = temp_12[k];
                                    break;
                                }
                            }
                        }
                    }

                    for (int k = 0; k < pointOfDevision; k++)
                    {
                        bool flag1 = true;
                        for (int m = 0; m < pointsAmount; m++)
                        {
                            if (temp_11[k] == child[m])
                            {
                                flag1 = false;
                            }
                        }
                        if (flag1)
                        {
                            for (int g = 0; g < pointsAmount; g++)
                            {
                                if (child[g] == 999999)
                                {
                                    child[g] = temp_11[k];
                                    break;
                                }
                            }
                        }
                    }
                }

                double mutationChance = double.Parse(mutationChanceTB.Text);

                if (rnd.NextDouble() < mutationChance)
                {
                    int point_1 = rnd.Next(1, pointsAmount - 1);
                    int point_2 = rnd.Next(1, pointsAmount - 1);

                    while (point_1 == point_2)
                    {
                        point_2 = rnd.Next(1, pointsAmount - 1);
                    }

                    for (int p = 0; p < Math.Abs(point_1 - point_2) / 2; p++)
                    {
                        if (point_1 > point_2)
                        {
                            int temp = child[point_2 + p];
                            child[point_2 + p] = child[point_1 - p - 1];
                            child[point_1 - p - 1] = temp;
                        }
                        else
                        {
                            int temp = child[point_1 + p];
                            child[point_1 + p] = child[point_2 - p - 1];
                            child[point_2 - p - 1] = temp;
                        }

                    }
                }

                for (int j = 0; j < pointsAmount; j++)
                {
                    population[i, j] = bestOfPopulation[i, j];
                    population[i + populationSize / 2, j] = child[j];
                }
            }

            return population;
        }

        async private Task<int[]> DisplayShortest(int[,] population)
        {
            int populationSize = int.Parse(populationSizeTB.Text);
            int pointsAmount = int.Parse(pointsAmountTB.Text);
            int[] shortest = new int[pointsAmount];
            double minDistance = 999999999;
            int position = 9999999;

            for (int j = 0; j < populationSize; j++)
            {
                if (population[j, 0] != -1)
                {
                    double distance = 0;
                    for (int k = 0; k < pointsAmount - 1; k++)
                    {
                        distance += CalculateDistance(population[j, k], population[j, k + 1]);
                    }
                    distance += CalculateDistance(population[j, 0], population[j, pointsAmount - 1]);
                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        position = j;
                    }
                }
            }

            genTotalDistanceLabel.Content = Round(minDistance,1);
            await CreateGraph(minDistance);

            for (int i = 0; i < pointsAmount; i++)
            {
                shortest[i] = population[position, i];
            }

            return shortest;
        }

        async private Task<int> ConnectGenetic(int[] shortest)
        {
            DeleteLastPath();

            int pointsAmount = int.Parse(pointsAmountTB.Text);

            for (int i = 0; i < pointsAmount; i++)
            {
                if (i == pointsAmount - 1)
                {
                    Line connection = new Line();
                    connection.X1 = Canvas.GetLeft(genEllipse[shortest[i]]) + 8;
                    connection.X2 = Canvas.GetLeft(genEllipse[shortest[0]]) + 8;
                    connection.Y1 = Canvas.GetTop(genEllipse[shortest[i]]) + 8;
                    connection.Y2 = Canvas.GetTop(genEllipse[shortest[0]]) + 8;
                    connection.StrokeThickness = 4;
                    connection.Stroke = new SolidColorBrush(Colors.Black);
                    connection.Visibility = Visibility.Visible;
                    geneticField.Children.Add(connection);
                }
                else
                {
                    Line connection = new Line();
                    connection.X1 = Canvas.GetLeft(genEllipse[shortest[i]]) + 8;
                    connection.X2 = Canvas.GetLeft(genEllipse[shortest[i + 1]]) + 8;
                    connection.Y1 = Canvas.GetTop(genEllipse[shortest[i]]) + 8;
                    connection.Y2 = Canvas.GetTop(genEllipse[shortest[i + 1]]) + 8;
                    connection.StrokeThickness = 4;
                    connection.Stroke = new SolidColorBrush(Colors.Black);
                    connection.Visibility = Visibility.Visible;
                    geneticField.Children.Add(connection);
                }

            }

            await Task.Delay(int.Parse(timeTB.Text));

            return 0;
        }

        private void DeleteLastPath()
        {
            geneticField.Children.Clear();

            int pointsAmount = int.Parse(pointsAmountTB.Text);

            for (int i = 0; i < pointsAmount; i++)
            {
                CreatePoint(i);
            }
        }

        async private void StartGreedyInit(int current) 
        {
            startGeneticButton.IsEnabled = false;
            stopButton.IsEnabled = true;
            startGreedyButton.IsEnabled = false;
            createFieldButton.IsEnabled = false;

            if (flag)
            {
                grTotalDistance = 0;
            }
            flag = true;
            await StartGreedy(current);
        }

        async private Task<int> StartGreedy(int current) 
        {
            if (flag)
            {
                stopButton.Click += (s, a) => StopGreedy();

                wasUsed[current] = "used";
                int amount = grEllipse.Length;

                int next = current;
                double distance = int.MaxValue;

                for (int i = 0; i < amount; i++)
                {
                    if (CalculateDistance(current, i) < distance && current != i && (wasUsed[i] == null || wasUsed[i] == ""))
                    {
                        distance = CalculateDistance(current, i);
                        next = lastPoint = i;
                    }
                }

                await Task.Delay(int.Parse(timeTB.Text));
                if (next != current)
                {
                    wasUsed[next] = "used";
                    ConnectGreedy(current, next, distance);
                    await StartGreedy(next);
                }
                else
                {
                    stopButton.IsEnabled = false;
                    startGeneticButton.IsEnabled = true;
                    createFieldButton.IsEnabled = true;
                    distance = CalculateDistance(current, 0);
                    ConnectGreedy(current, 0, distance);
                }
            }

            return 0;
        }

        private Task<int> CreateGraph(double minDistance)
        {
            graph.Series[0].Points.Add(Round(grTotalDistance,1));
            graph.Series[0].BorderWidth = 4;

            graph.Series[1].Points.Add(Round(minDistance, 1));       
            graph.Series[1].BorderWidth = 4;

            return Task.FromResult(0);
        }

        private void StopGenetic()
        {
            flag1 = false;
            startGeneticButton.IsEnabled = true;
            stopButton.IsEnabled = false;
            createFieldButton.IsEnabled = true;
        }

        private void StopGreedy() 
        {
            flag = false;
            startGreedyButton.IsEnabled = true;
            stopButton.IsEnabled = false;
            createFieldButton.IsEnabled = true;
        }

        private void ConnectGreedy(int current, int next, double distance) 
        {
            Line connection = new Line();
            connection.X1 = Canvas.GetLeft(grEllipse[current]) + 8;
            connection.X2 = Canvas.GetLeft(grEllipse[next]) + 8;
            connection.Y1 = Canvas.GetTop(grEllipse[current]) + 8;
            connection.Y2 = Canvas.GetTop(grEllipse[next]) + 8;
            connection.StrokeThickness = 4;
            connection.Stroke = new SolidColorBrush(Colors.Black);
            connection.Visibility = Visibility.Visible;
            greedyField.Children.Add(connection);

            grTotalDistance += distance;
            grTotalDistanceLabel.Content = Round(grTotalDistance, 1);
        }

        private double CalculateDistance(int first, int second) 
        {
            return Sqrt(Pow(pointX[first] - pointX[second], 2) + Pow(pointY[first] - pointY[second], 2));
        }
    }
}









