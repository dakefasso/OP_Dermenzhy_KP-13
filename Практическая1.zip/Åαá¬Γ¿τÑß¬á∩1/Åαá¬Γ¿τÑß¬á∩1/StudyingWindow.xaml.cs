﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows;

namespace Практическая1
{
    /// <summary>
    /// Interaction logic for StudyingWindow.xaml
    /// </summary>
    public partial class StudyingWindow : Window
    {
        Stopwatch stopWatch = new Stopwatch();
        List<string> gaps = new List<string>();
        public StudyingWindow()
        {
            InitializeComponent();
            exit.Click += (s, a) => Exit();
            saveButton.Click += (s, a) => SaveKeyWord(s, a);
            inputField.TextChanged += (s, a) => Input(s, a);

            inputField.IsEnabled = false;
        }
        private void Exit()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }

        private void SaveKeyWord(object s, RoutedEventArgs a)
        {
            string path = @"C:\Users\Admin\Desktop\Дз КПИ\ОП\2 семестр\Практические\Практика1\Кодове слово.txt";
            string keyWord = keyWordField.Text;

            if (keyWord.Length != 0)
            {
                using (StreamWriter sw = new StreamWriter(path, false, System.Text.Encoding.Default))
                {
                    sw.WriteLine(keyWord);
                    sw.Close();
                }

                keyWordField.IsEnabled = false;
                inputField.IsEnabled = true;
            }
        }

        private void Input(object s, RoutedEventArgs a)
        {
            string sampleText;
            string inputText = inputField.Text;
            string path = @"C:\Users\Admin\Desktop\Дз КПИ\ОП\2 семестр\Практические\Практика1\Кодове слово.txt";
            string resultPath = @"C:\Users\Admin\Desktop\Дз КПИ\ОП\2 семестр\Практические\Практика1\Еталон.txt";

            using (StreamReader sr = new StreamReader(path))
            {
                sampleText = sr.ReadToEnd();
                sampleText = sampleText.Substring(0, sampleText.Length - 2);
            }

            if(inputText.Length > 0)
            {
                if (sampleText.Substring(0, inputText.Length) == inputText)
                {
                    if (inputText.Length != 1)
                    {
                        stopWatch.Stop();
                        TimeSpan ts = stopWatch.Elapsed;

                        string elapsedTime = ts.ToString().Substring(7, 7);
                        gaps.Add(elapsedTime);
                        stopWatch.Reset();
                    }
                    stopWatch.Start();

                    //последняя буква
                    if (inputText == sampleText)
                    {
                        using (StreamWriter sw = new StreamWriter(resultPath, false, System.Text.Encoding.Default))
                        {
                            sw.WriteLine(String.Join(";", gaps));
                        }
                        inputField.Text = "";
                    }
                }
                else
                {
                    //ошибка в букве
                    if (inputText.Length != 1)
                    {
                        stopWatch.Stop();
                        stopWatch.Reset();
                    }
                    gaps.Clear();
                    inputField.Text = "";
                }
            }
            
        }
    }
}
