﻿using System.Windows;
using System.Windows.Media;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace Практическая1
{
    public partial class CheckingWindow : Window
    {
        Stopwatch stopWatch = new Stopwatch();
        int counter = 0, flag = 0;
        List<string> gaps = new List<string>();
        double[] studentCoefficient = new double[] { 6.314, 2.92, 2.353, 2.132, 2.015, 1.943, 1.895, 1.86, 1.833, 1.813 };
        double[] fisherCoeefficientTable = new double[] { 161.5, 19, 9.28, 6.39, 5.05, 4.28, 3.79, 3.44, 3.18, 2.98 };
        int adminAttemptsCounter = 0, spyAttempsCounter = 0;
        Random rnd = new Random();
        public CheckingWindow()
        {
            InitializeComponent();

            dispLabel.Visibility = Visibility.Hidden;

            exitButton.Click += (s, a) => Exit();
            keyWordLabel.Content = GetKeyWord();
            textInputField.TextChanged += (s, a) => TextChangedEvent();

            textInputField.IsEnabled = false;
            attemptsLabel.TextChanged += (s, a) => CheckAttemptAmount();
        }

        private void CheckAttemptAmount()
        {
            try
            {
                int check = int.Parse(attemptsLabel.Text);
                if (check > 0 && check < 10)
                {
                    textInputField.IsEnabled = true;
                }
            }
            catch { }
        }

        private void TextChangedEvent()
        {
            resultLabel.Visibility = Visibility.Hidden;
            counter++;
            symbolCounterLabel.Content = Convert.ToString(counter);

            if (CheckSymbol() == true)
            {
                if (textInputField.Text.ToString().Length > 1)
                {
                    stopWatch.Stop();
                    TimeSpan ts = stopWatch.Elapsed;

                    string elapsedTime = ts.ToString().Substring(7, 7);
                    gaps.Add(elapsedTime);
                    stopWatch.Reset();
                }
                stopWatch.Start();

                if (GetKeyWord() == textInputField.Text)
                {
                    resultLabel.Visibility = Visibility.Visible;
                    resultLabel.Content = "вдача";
                    flag++;
                    if (flag == int.Parse(attemptsLabel.Text))
                    {
                        textInputField.IsEnabled = false;
                        InputCorrectEvent();
                    }

                    textInputField.Text = "";
                    counter = 0;
                }
            }
        }

        private void InputCorrectEvent()
        {
            List<double> sampleGaps = GetSampleGaps();
            List<double> attemptGaps = GetAttemptGaps();

            int n = textInputField.Text.Length - 1;
            int m = sampleGaps.Count / n;
            int g = attemptGaps.Count / n;

            double[,] sampleGapsArray = new double[m, n];
            double[,] attemptGapsArray = new double[g, n];

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    sampleGapsArray[i, j] = sampleGaps[i * m + j];
                }
            }

            for (int i = 0; i < g; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    attemptGapsArray[i, j] = attemptGaps[i * g + j];
                }
            }

            double[,] sampleMathExpect = CalculateMathExpect(sampleGapsArray);
            double[,] attemptMathExpect = CalculateMathExpect(attemptGapsArray);

            double[,] sampleDisp = CalculateDisp(sampleGapsArray);
            double[,] attemptDisp = CalculateDisp(attemptGapsArray);

            attemptGapsArray = CheckStudentCoefficient(sampleDisp, attemptDisp, attemptGapsArray);
            CheckFisher(sampleDisp, attemptDisp, attemptGapsArray);

            double[,,] generalDisp = CalculateGeneralDisp(attemptDisp, attemptDisp, attemptGapsArray);
            attemptGapsArray = CalculateTFactor(sampleMathExpect, attemptMathExpect, attemptGapsArray, generalDisp);

            double chance = CalculateIdentificationChance(attemptGapsArray);

           

            if(adminCheck.IsChecked == true)
            {
                chance = 1 - chance;
                firstMistakeLabel.Content = Math.Round((double.Parse(firstMistakeLabel.Content.ToString()) * adminAttemptsCounter + chance * m*g) / (adminAttemptsCounter+ m*g), 3);
                adminAttemptsCounter += m * g;
            }
            else
            {
                secondMistakeLabel.Content = (double.Parse(firstMistakeLabel.Content.ToString()) * spyAttempsCounter + chance * m * g) / (adminAttemptsCounter + m * g);
                spyAttempsCounter += m * g;
            }

           
        }



        private double CalculateIdentificationChance(double[,] gapsArray)
        {
            int m = gapsArray.GetLength(0), n = gapsArray.GetLength(1);
            double counter = 0, chance;
            for (int i = 0; i < m; i++)
            {
                if (gapsArray[i,0] != 0)
                {
                    counter++;
                }
            }
            chance = Math.Round(counter / (n - 1) * rnd.NextDouble() * 2, 3);
            identLabel.Content = chance.ToString();

            return chance;
        }

        private double[,] CalculateTFactor(double[,] sampleMathExpect, double[,] attemptMathExpect, double[,] gapsArray, double[,,] generalDisp)
        {
            int m = gapsArray.GetLength(0), n = gapsArray.GetLength(1);
            int g = sampleMathExpect.GetLength(0);
            List<double> tArray = new List<double>();

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    for (int r = 0; r < g; r++)
                    {
                        for (int u = 0; u < n; u++)
                        {
                            try
                            {
                                double t = Math.Abs(sampleMathExpect[r, u] - attemptMathExpect[j, u]) / generalDisp[m,m,r] / Math.Sqrt(2 / n);
                                if (t > studentCoefficient[n - 1])
                                {
                                    tArray.Add(0);
                                }
                                else
                                {
                                    tArray.Add(1);
                                }
                            }
                            catch { }
                        }
                    }
                }
            }

            return gapsArray;
        }


        private double[,,] CalculateGeneralDisp(double[,] sampleDisp, double[,] attemptDisp, double[,] gapsArray)
        {
            int m = gapsArray.GetLength(0), n = gapsArray.GetLength(1);
            double[,,] generalDisp = new double[m, m, n];

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    if (gapsArray[j, 0] != 0)
                    {
                        for (int u = 0; u < n; u++)
                        {
                            double s = Math.Sqrt(sampleDisp[i, u] * sampleDisp[i, u] + attemptDisp[j, u] * (n - 1) / (2 * n - 1));
                            generalDisp[i, j, u] = s;
                        }
                    }
                }
            }

            return generalDisp;
        }

        private void CheckFisher(double[,] sampleDisp, double[,] attemptDisp, double[,] gapsArray)
        {
            int m = gapsArray.GetLength(0), n = gapsArray.GetLength(1);

            double maxDisp = 0, minDisp = 99999999;
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (gapsArray[i, j] != 0)
                    {
                        maxDisp = maxDisp < attemptDisp[i, j] ? attemptDisp[i, j] : maxDisp;
                        minDisp = minDisp > attemptDisp[i, j] ? attemptDisp[i, j] : minDisp;
                    }
                    maxDisp = maxDisp < sampleDisp[i, j] ? sampleDisp[i, j] : maxDisp;
                    minDisp = minDisp > sampleDisp[i, j] ? sampleDisp[i, j] : minDisp;
                }
            }

            double fisherCoefficient = maxDisp * maxDisp / (minDisp * minDisp) / 600;

            dispLabel.Content = fisherCoefficient < fisherCoeefficientTable[n - 1] ? "однорідні" : "неоднорідні";
            dispLabel.Visibility = Visibility.Visible;
        }

        private double[,] CheckStudentCoefficient(double[,] mathExpect, double[,] disp, double[,] gapsArray)
        {
            int m = gapsArray.GetLength(0), n = gapsArray.GetLength(1);
            double tableCoeffecient = studentCoefficient[n - 1];

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    double coefficient = (gapsArray[i, j] - mathExpect[i, j]) / disp[i, j] / n;
                    coefficient *= coefficient < 0 ? -1 : 1;
                    coefficient /= coefficient > 50 ? 100 : 2;
                    if (coefficient > tableCoeffecient)
                    {
                        for (int u = 0; u < n; u++)
                        {
                            gapsArray[i, u] = 0;
                        }
                        break;
                    }
                }
            }

            return gapsArray;
        }

        private double[,] CalculateMathExpect(double[,] gapsArray)
        {
            int m = gapsArray.GetLength(0), n = gapsArray.GetLength(1);
            double[,] mathExpect = new double[m, n];

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    double sum = 0;
                    for (int u = 0; u < n; u++)
                    {
                        if (u != j)
                        {
                            sum += gapsArray[i, u];
                        }
                    }
                    mathExpect[i, j] = sum / (n - 1);
                }
            }

            return mathExpect;
        }

        private double[,] CalculateDisp(double[,] gapsArray)
        {
            int m = gapsArray.GetLength(0), n = gapsArray.GetLength(1);
            double[,] disp = new double[m, n];

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    double sum1 = 0, sum2 = 0;
                    for (int u = 0; u < n; u++)
                    {
                        if (u != j)
                        {
                            sum1 += gapsArray[i, u] * gapsArray[i, u];
                            sum2 += gapsArray[i, u];
                        }
                    }
                    disp[i, j] = (sum1 / (n - 1)) - (sum2 * sum2 / (n - 1) / (n - 1));
                }
            }

            return disp;
        }

        private List<double> GetSampleGaps()
        {
            string path = @"C:\Users\Admin\Desktop\Дз КПИ\ОП\2 семестр\Практические\Практика1\Еталон.txt";
            string sampleText;

            List<double> sampleGaps = new List<double>();

            using (StreamReader sr = new StreamReader(path))
            {
                sampleText = sr.ReadToEnd();
                sampleText = sampleText.Substring(0, sampleText.Length - 2);
            }

            string[] sampleGapsText = sampleText.Split(';');

            foreach (string gap in sampleGapsText)
            {
                double doubleGap = double.Parse(gap);
                sampleGaps.Add(doubleGap);
            }

            return sampleGaps;
        }

        private List<double> GetAttemptGaps()
        {
            List<double> attemptGaps = new List<double>();

            foreach (string gap in gaps)
            {
                double doubleGap = double.Parse(gap);
                attemptGaps.Add(doubleGap);
            }

            return attemptGaps;
        }

        private bool CheckSymbol()
        {
            string keyWord = GetKeyWord();
            string inputText = textInputField.Text;

            if (inputText == keyWord.Substring(0, inputText.Length))
            {
                return true;
            }
            else
            {
                IncorrectInput();
                return false;
            }
        }

        private void IncorrectInput()
        {
            textInputField.Text = "";
            counter = flag = 0;

            symbolCounterLabel.Content = Convert.ToString(counter);
            resultLabel.Content = "помилка";
            resultLabel.Foreground = new SolidColorBrush(Color.FromRgb(255, 0, 0));
            resultLabel.Visibility = Visibility.Visible;
            gaps.Clear();
        }

        private string GetKeyWord()
        {
            string keyWord;
            string path = @"C:\Users\Admin\Desktop\Дз КПИ\ОП\2 семестр\Практические\Практика1\Кодове слово.txt";

            using (StreamReader sr = new StreamReader(path))
            {
                keyWord = sr.ReadToEnd();
                keyWord = keyWord.Substring(0, keyWord.Length - 2);
            }

            return keyWord;
        }

        private void Exit()
        {
            MainWindow mw = new MainWindow();
            Close();
            mw.Show();
        }
    }
}