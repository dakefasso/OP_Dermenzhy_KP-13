﻿using System.Windows;

namespace Практическая1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            studyingModeButton.Click += (s, a) => Studying();
            checkModeButton.Click += (s, a) => Checking();
            exitButton.Click += (s, a) => Close();
        }
        private void Studying()
        {
            StudyingWindow sw = new StudyingWindow();
            Close();
            sw.Show();
        }

        private void Checking()
        {
            CheckingWindow cw = new CheckingWindow();
            Close();
            cw.Show();
        }
    }
}
