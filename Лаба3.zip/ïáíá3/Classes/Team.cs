﻿namespace Лаба3
{
    public class Team
    {
        public string TeamName { get; set; }
        public string CoachName { get; set; }
        public int PreviousPlace { get; set; }
    }
}
