﻿using System;
using System.Collections.Generic;
namespace Лаба3
{
    public class Stadium
    {
        public string City { get; set; }
        public string HomeTeam { get; set; }
        public string StadiumName { get; set; }
        public int Capacity { get; set; }
    }
}
